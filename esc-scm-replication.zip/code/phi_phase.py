"""Phase averages of the cross-donor exposure effect phi_t with delete-one-donor jackknife errors."""
import json
from ebsc import exposure_effects_phase
from app import wide, BASE, EXT, YEARS, PRE, PH, S_RENTS
out = {}
for k, pool in [('base', BASE), ('ext', EXT)]:
    Y = wide(pool)
    out[k] = exposure_effects_phase(Y[pool].values, S_RENTS[pool].values, PRE, list(YEARS).index(2011),
                                    {p: (YEARS >= a) & (YEARS <= b) for p, (a, b) in PH.items()})
    print(k, {p: (round(100 * v[0], 3), round(100 * v[1], 3), round(v[0] / v[1], 2)) for p, v in out[k].items()})
json.dump(out, open('../results/phi_phase.json', 'w'))
