"""Synthetic controls under out-of-span common shocks (the method of the paper).

Diagnostics
  donor_factors       latent factors from donors' outcomes, optionally orthogonal to exposure (Section 4.1)
  shock_leverage      kappa_t = sqrt(g_t' S0^{-1} g_t) for every period (Proposition 1)
  phase_leverage      kappa of a phase average (Proposition 1)
  partial_leverage    ell_t: residual of the observed shock on the latent factors, divided by its
                      pre-treatment root mean square (Corollary 1)
  leverage_sc         kappa for SC with g_t = (1, lambda_t, x_t)
  leverage_easc       kappa^EA = sqrt(kappa_lambda^2 + ell_b^2) (Proposition 4(d))
  exposure_imbalance  EI(w) = s_1 - sum_j w_j s_j; min_imbalance = d_min (Proposition 3)
Estimators
  frontier_path / ebsc_path   exposure-fit frontier w(d); path[0] is EBSC-min (eq. 12)
  exposure_effects    phi_t and jackknife s.e. (eq. 9); exposure_effects_phase for phase averages
  easc                exposure-augmented SC (eq. 10) for any weights
  easc_select / easc_tuned    EASC*: frontier point chosen by criterion (13)
Inference
  cv_bias_aware, bias_aware_ci, breakdown_M   Proposition 5
"""
import numpy as np, pandas as pd, cvxpy as cp
from scipy.stats import ncx2, norm


# ---------------------------------------------------------------- factor estimation
def donor_factors(Y0, k=2, s=None):
    """Latent factors from donors' outcomes (T x J), all periods (donors are untreated).
    Unit means and cross-sectional (time) means are removed. If exposure s is given, the
    cross-sectional projection on s is removed each period first, so that the factors are
    orthogonal to the exposure channel."""
    Z = Y0 - Y0.mean(axis=0, keepdims=True)
    Z = Z - Z.mean(axis=1, keepdims=True)
    if s is not None:
        sc = (s - s.mean()) / s.std()
        Z = Z - np.outer(Z @ sc / (sc @ sc), sc)
    U, sv, Vt = np.linalg.svd(Z, full_matrices=False)
    F = U[:, :k] * sv[:k] / np.sqrt(Z.shape[0])
    return F, sv


def shock_leverage(G, pre):
    """kappa_t for every t given factor matrix G (T x p, include a constant) and a pre mask."""
    S0 = G[pre].T @ G[pre] / pre.sum()
    Si = np.linalg.pinv(S0)
    return np.sqrt(np.einsum('ti,ij,tj->t', G, Si, G))


def partial_leverage(x, F, pre):
    """Standardized deviation of observed shock x_t from its pre-period linear relation with
    latent factors F (Corollary 1): (x_t - xhat_t) / sd_pre(x - xhat)."""
    X = np.column_stack([np.ones(len(x)), F])
    b = np.linalg.lstsq(X[pre], x[pre], rcond=None)[0]
    res = x - X @ b
    sr = np.sqrt(np.mean(res[pre] ** 2))          # sigma_r in Corollary 1 (pre-period RMS of the residual)
    return res / sr, float(1 - res[pre].var() / x[pre].var())


def exposure_imbalance(s1, s0, w):
    return float(s1 - s0 @ w)


# ---------------------------------------------------------------- exposure effects from donors
def exposure_effects(Y0, s0, pre, base_idx, controls=True):
    """phi_t (eq. 9 of the paper): coefficient on exposure in the cross-donor regression of Y_jt - Y_jb on
    (1, s_j, c_j), where c_j is donor j's growth within each third of the pre-treatment years before b
    (proxies for composite latent loadings, Assumption 3). Returns phi (T,), jackknife s.e. (T,)."""
    T, J = Y0.shape
    D = Y0 - Y0[base_idx][None, :]
    pre_idx = np.where(pre)[0]; pre_idx = pre_idx[pre_idx < base_idx]     # controls end before the base period
    thirds = np.array_split(pre_idx, 3)
    C = np.column_stack([Y0[th[-1]] - Y0[th[0]] for th in thirds]) if controls else np.zeros((J, 0))
    X = np.column_stack([np.ones(J), s0, C])
    def fit(Xm, Dm):
        return np.linalg.lstsq(Xm, Dm.T, rcond=None)[0][1]
    phi = fit(X, D)
    jk = np.array([fit(np.delete(X, j, 0), np.delete(D, j, 1)) for j in range(J)])
    se = np.sqrt((J - 1) / J * ((jk - jk.mean(0)) ** 2).sum(0))
    return phi, se


# ---------------------------------------------------------------- estimators
def _sc_weights(a, A, s1=None, s0=None, tol=None, ridge=0.0):
    J = A.shape[1]; w = cp.Variable(J)
    cons = [w >= 0, cp.sum(w) == 1]
    if tol is not None:
        cons.append(cp.abs(s1 - s0 @ w) <= tol)
    cp.Problem(cp.Minimize(cp.sum_squares(a - A @ w) + ridge * cp.sum_squares(w)), cons).solve(solver=cp.CLARABEL)
    if w.value is None:
        return None
    v = np.clip(w.value, 0, None); return v / v.sum()


def min_imbalance(s1, s0):
    """dist(s1, conv{s_j}) for scalar exposure."""
    return float(max(0.0, s1 - s0.max(), s0.min() - s1))


def ebsc_path(y1, Y0, pre, s1, s0, grid=None):
    """Exposure-fit frontier: weights for a grid of imbalance tolerances above the minimum."""
    dmin = min_imbalance(s1, s0)
    w_sc = _sc_weights(y1[pre], Y0[pre])
    d_sc = abs(exposure_imbalance(s1, s0, w_sc))
    grid = grid if grid is not None else np.linspace(0, 1, 21)
    out = []
    for g in grid:
        tol = dmin + g * max(d_sc - dmin, 0) + 1e-9
        w = _sc_weights(y1[pre], Y0[pre], s1, s0, tol)
        if w is None:
            continue
        r = y1[pre] - Y0[pre] @ w
        out.append(dict(frac=float(g), tol=float(tol), w=w, ei=exposure_imbalance(s1, s0, w),
                        rmspe=float(np.sqrt(np.mean(r ** 2)))))
    return out








def easc(y1, Y0, w, s1, s0, phi):
    """Exposure-augmented SC: tau_t = y1t - Y0t w - phi_t * EI(w)."""
    ei = exposure_imbalance(s1, s0, w)
    return y1 - Y0 @ w - phi * ei, ei


# ---------------------------------------------------------------- inference
def cv_bias_aware(b, alpha=0.05):
    """Smallest c with P(|N(b,1)| <= c) >= 1-alpha (Armstrong and Kolesar 2020)."""
    b = abs(b)
    if b < 1e-10:
        return norm.ppf(1 - alpha / 2)
    return float(np.sqrt(ncx2.ppf(1 - alpha, df=1, nc=b ** 2)))


def bias_aware_ci(tau, B, sd, alpha=0.05):
    """Proposition 5: tau +/- sd * cv(B / sd), elementwise."""
    half = np.array([cv_bias_aware(b / s, alpha) * s for b, s in zip(B, sd)])
    return tau - half, tau + half


# ---------------------------------------------------------------- tuned EASC and sensitivity analysis
def easc_tuned(y1, Y0, pre, s1, s0, phi, se_phi, kappa_lat, post=None):
    """Choose the exposure tolerance on the EBSC frontier that minimises the estimated post-treatment
    MSE of the augmented estimator:  kappa_lat_t^2 * eta(w)^2 + se_phi_t^2 * EI(w)^2, where
    eta(w)^2 = RMSPE(w)^2 - RMSPE(w_SC)^2 is the extra pre-treatment misfit induced by balancing,
    treated as systematic. Returns the chosen frontier point and the whole frontier."""
    post = (~pre) if post is None else post
    path = ebsc_path(y1, Y0, pre, s1, s0, grid=np.linspace(0, 1, 41))
    r_sc = path[-1]['rmspe']
    best = None
    for p in path:
        eta2 = max(0.0, p['rmspe'] ** 2 - r_sc ** 2)
        mse = float(np.mean(kappa_lat[post] ** 2 * eta2 + se_phi[post] ** 2 * p['ei'] ** 2))
        p.update(eta=np.sqrt(eta2), crit=mse)
        if best is None or mse < best['crit']:
            best = p
    return best, path




def breakdown_M(tau_bar, kappa_bar, rmspe, sd_bar, alpha=0.05, Mmax=5.0):
    """Largest M such that the bias-aware interval for an averaged effect excludes zero."""
    lo, hi = 0.0, Mmax
    def excl(M):
        B = M * kappa_bar * rmspe
        h = cv_bias_aware(B / sd_bar, alpha) * sd_bar
        return abs(tau_bar) > h
    if not excl(0.0):
        return 0.0
    if excl(Mmax):
        return Mmax
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if excl(mid) else (lo, mid)
    return lo


# ---------------------------------------------------------------- additions used in the paper
def phase_leverage(G, pre, mask):
    """Leverage of a phase average (Proposition 1): sqrt(gbar' S0^{-1} gbar), gbar = mean of g_t over mask.
    Sharper than the average of kappa_t because the bias of an average is Delta' gbar."""
    S0 = G[pre].T @ G[pre] / pre.sum()
    gb = G[mask].mean(axis=0)
    return float(np.sqrt(gb @ np.linalg.pinv(S0) @ gb))


def sc_weights_fast(a, A):
    """Simplex least squares via augmented NNLS (identical solution to _sc_weights without constraints)."""
    from scipy.optimize import nnls
    M = 1e3 * (np.abs(A).max() + 1.0)
    w, _ = nnls(np.vstack([A, M * np.ones(A.shape[1])]), np.append(a, M), maxiter=5000)
    w = np.clip(w, 0, None); return w / w.sum()


class Frontier:
    """Exposure-fit frontier R(d) = min{ ||a - A w|| : w in simplex, |s1 - s0'w| <= d } with the
    problem compiled once (cvxpy DPP) and re-solved for each tolerance d."""
    def __init__(self, a, A, s1, s0):
        J = A.shape[1]; self.w = cp.Variable(J); self.d = cp.Parameter(nonneg=True)
        self.a, self.A, self.s1, self.s0 = a, A, s1, s0
        self.p = cp.Problem(cp.Minimize(cp.sum_squares(a - A @ self.w)),
                            [self.w >= 0, cp.sum(self.w) == 1, cp.abs(s1 - s0 @ self.w) <= self.d])

    def solve(self, d):
        self.d.value = float(d)
        try:
            self.p.solve(solver=cp.CLARABEL)
        except Exception:
            return None
        if self.w.value is None:
            return None
        v = np.clip(self.w.value, 0, None); return v / v.sum()


def frontier_path(y1, Y0, pre, s1, s0, n=21, w_sc=None):
    dmin = min_imbalance(s1, s0)
    w_sc = sc_weights_fast(y1[pre], Y0[pre]) if w_sc is None else w_sc
    d_sc = abs(exposure_imbalance(s1, s0, w_sc))
    fr = Frontier(y1[pre], Y0[pre], s1, s0); out = []
    for g in np.linspace(0, 1, n):
        tol = dmin + g * max(d_sc - dmin, 0) + 1e-9
        w = w_sc if g == 1.0 else fr.solve(tol)
        if w is None:
            continue
        r = y1[pre] - Y0[pre] @ w
        out.append(dict(frac=float(g), tol=float(tol), w=w, ei=exposure_imbalance(s1, s0, w),
                        rmspe=float(np.sqrt(np.mean(r ** 2)))))
    return out


def easc_select(path, kappa_lat, se_phi, post):
    """Tuned EASC (EASC*): the frontier point minimising the estimated post-period MSE
    mean_t[ kappa_lat_t^2 * (RMSPE(w)^2 - RMSPE_SC^2) + se_phi_t^2 * EI(w)^2 ]."""
    r_sc = path[-1]['rmspe']; best = None
    for p in path:
        eta2 = max(0.0, p['rmspe'] ** 2 - r_sc ** 2)
        crit = float(np.mean(kappa_lat[post] ** 2 * eta2 + se_phi[post] ** 2 * p['ei'] ** 2))
        p.update(eta=np.sqrt(eta2), crit=crit)
        if best is None or crit < best['crit']:
            best = p
    return best


def leverage_sc(x, Fl, pre, mask):
    """kappa for the SC bias bound of a (phase-)average, g_t = (1, lambda_t, x_t) (Proposition 1, Corollary 1)."""
    return phase_leverage(np.column_stack([np.ones(len(x)), Fl, x]), pre, mask)


def leverage_easc(x, Fl, pre, mask, b):
    """kappa for the EASC bias bound (Proposition 4): sqrt(kappa_lambda(mean lambda)^2 + ell_b^2)."""
    kl = phase_leverage(np.column_stack([np.ones(len(x)), Fl]), pre, mask)
    pl, _ = partial_leverage(x, Fl, pre)
    return float(np.sqrt(kl ** 2 + pl[b] ** 2))


def exposure_effects_phase(Y0, s0, pre, base_idx, masks, controls=True):
    """Phase averages of phi_t with delete-one-donor jackknife standard errors."""
    T, J = Y0.shape
    D = Y0 - Y0[base_idx][None, :]
    pre_idx = np.where(pre)[0]; thirds = np.array_split(pre_idx[pre_idx < base_idx], 3)
    C = np.column_stack([Y0[th[-1]] - Y0[th[0]] for th in thirds]) if controls else np.zeros((J, 0))
    X = np.column_stack([np.ones(J), s0, C])
    fit = lambda Xm, Dm: np.linalg.lstsq(Xm, Dm.T, rcond=None)[0][1]
    phi = fit(X, D); jk = np.array([fit(np.delete(X, j, 0), np.delete(D, j, 1)) for j in range(J)])
    out = {}
    for k, m in masks.items():
        a = phi[m].mean(); ja = jk[:, m].mean(1)
        se = np.sqrt((J - 1) / J * ((ja - ja.mean()) ** 2).sum()); out[k] = (float(a), float(se))
    return out
