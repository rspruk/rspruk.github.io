"""Inference for the application: placebo ranks for SC and EASC, leverage-based sensitivity
(bias-aware intervals indexed by M) and breakdown values, jackknife uncertainty of the correction."""
import numpy as np, pandas as pd, pickle, warnings
warnings.filterwarnings('ignore')
from ebsc import (leverage_sc, leverage_easc, phase_leverage, donor_factors, shock_leverage, exposure_effects, easc, _sc_weights, exposure_imbalance,
                  bias_aware_ci, breakdown_M, cv_bias_aware)
from app import wide, BASE, EXT, YEARS, PRE, PH, S_RENTS, X

def run_unit(Y, treated, pool, s):
    y1 = Y[treated].values; Y0 = Y[pool].values; s1 = float(s[treated]); s0 = s[pool].values
    w = _sc_weights(y1[PRE], Y0[PRE]); g = y1 - Y0 @ w
    phi, se = exposure_effects(Y0, s0, PRE, list(YEARS).index(2011))
    ge, ei = easc(y1, Y0, w, s1, s0, phi)
    F, _ = donor_factors(Y0, k=2); G = np.column_stack([np.ones(len(YEARS)), F]); kap = shock_leverage(G, PRE)
    Fl, _ = donor_factors(Y0, k=2, s=s0); Gl = np.column_stack([np.ones(len(YEARS)), Fl]); kapl = shock_leverage(Gl, PRE)
    rm = float(np.sqrt(np.mean(g[PRE] ** 2)))
    return dict(g=g, ge=ge, ei=ei, se=se, kap=kap, kapl=kapl, rmspe=rm, G=G, Gl=Gl, w=w, phi=phi, Fl=Fl)

def phase_mean(v, a, b):
    m = (YEARS >= a) & (YEARS <= b); return float(np.mean(v[m]))

out = {}
for key, pool in [('base', BASE), ('ext', EXT)]:
    Y = wide(pool); res = {'IRN': run_unit(Y, 'IRN', pool, S_RENTS)}
    for u in pool:
        others = [d for d in pool if d != u]
        res[u] = run_unit(Y[[u] + others].rename(columns={u: u}), u, others, S_RENTS)
    rows = []
    for est, gk in [('SC', 'g'), ('EASC', 'ge')]:
        for ph, (a, b) in PH.items():
            vals = {u: phase_mean(r[gk], a, b) for u, r in res.items()}
            rat = {u: np.sqrt(np.mean(r[gk][(YEARS >= a) & (YEARS <= b)] ** 2)) / r['rmspe'] for u, r in res.items()}
            v = pd.Series(vals); rr = pd.Series(rat); n = len(v)
            ir = res['IRN']
            # noise scale: placebo phase-average gaps standardised by each unit's own pre-treatment RMSPE,
            # rescaled to Iran's pre-treatment RMSPE (the post/pre logic of Abadie et al. 2010)
            z = pd.Series({u: vals[u] / r['rmspe'] for u, r in res.items() if u != 'IRN'})
            sd = float(z.std(ddof=1) * ir['rmspe'])
            # alternative: raw dispersion among placebos with pre-MSPE <= 5x Iran's
            keep = [u for u, r in res.items() if u != 'IRN' and r['rmspe'] ** 2 <= 5 * ir['rmspe'] ** 2]
            sd5 = float(pd.Series({u: vals[u] for u in keep}).std(ddof=1))
            sdm = float(1.4826 * np.median(np.abs(z - z.median())) * ir['rmspe'])
            if est == 'EASC':
                ext = float(abs(ir['ei']) * np.mean(ir['se'][(YEARS >= a) & (YEARS <= b)]))
                sd = float(np.sqrt(sd ** 2 + ext ** 2)); sdm = float(np.sqrt(sdm ** 2 + ext ** 2))
                kbar = leverage_easc(X, ir['Fl'], PRE, (YEARS >= a) & (YEARS <= b), list(YEARS).index(2011))
            else:
                kbar = leverage_sc(X, ir['Fl'], PRE, (YEARS >= a) & (YEARS <= b))
            tau = vals['IRN']
            ci = {}
            for M in (0.0, 0.25, 0.5, 1.0):
                h = cv_bias_aware(M * kbar * ir['rmspe'] / sd) * sd
                ci[M] = (tau - h, tau + h)
            Mstar = breakdown_M(tau, kbar, ir['rmspe'], sd); Mstar_mad = breakdown_M(tau, kbar, ir['rmspe'], sdm)
            pval = (1 + sum(abs(vals[u]) / res[u]['rmspe'] >= abs(tau) / ir['rmspe'] for u in res if u != 'IRN')) / n
            rows.append(dict(est=est, phase=ph, tau=tau, rank_ratio=int((rr >= rr['IRN']).sum()), n=n,
                             rank_dir=int((v <= v['IRN']).sum()) if tau < 0 else int((v >= v['IRN']).sum()),
                             sd=sd, sd5=sd5, sdm=sdm, n5=len(keep), kbar=kbar, rmspe=ir['rmspe'], Mstar=Mstar, Mstar_mad=Mstar_mad, pval=pval,
                             ci0=ci[0.0], ci05=ci[0.5], ci1=ci[1.0]))
    df = pd.DataFrame(rows); out[key] = dict(table=df, res=res)
    print(f'\n== {key}'); print(df[['est', 'phase', 'tau', 'rank_ratio', 'rank_dir', 'n', 'sd', 'sdm', 'kbar', 'Mstar', 'Mstar_mad', 'pval']].round(3).to_string())
    for _, r in df.iterrows():
        print(f"  {r.est:4s} {r.phase:6s} tau={r.tau:+.3f}  CI(M=0)=[{r.ci0[0]:+.3f},{r.ci0[1]:+.3f}]  CI(M=.5)=[{r.ci05[0]:+.3f},{r.ci05[1]:+.3f}]  CI(M=1)=[{r.ci1[0]:+.3f},{r.ci1[1]:+.3f}]")
pickle.dump(out, open('../results/app_inference.pkl', 'wb'))
