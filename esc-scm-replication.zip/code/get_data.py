"""Fresh download of every external series (run on a machine with internet access).

    pip install wbgapi
    python get_data.py                     -> ../data/fresh/{gdp,gdi,inf}_api.csv, ../data/fresh/oilrents.csv, ../data/fresh/brent.csv
    WDI_DIR=../data/fresh sh ../run_all.sh  -> re-runs the pipeline with fresh WDI GDP data

The oil-rent and Brent files shipped in ../data/ were transcribed from World Bank API and FRED responses
on 2 October 2026; compare them with the fresh pull before submission (the script prints the largest differences)."""
import os, io, urllib.request, pandas as pd, wbgapi as wb
ISO = ('IRN KAZ NGA ECU MEX COL BRA JOR ROU BGR VNM ZAF PHL THA KEN CHL PER CRI DOM PAN AZE AGO '
       'IDN MYS MAR EGY SRB TUN TUR').split()
OUT = '../data/fresh'; os.makedirs(OUT, exist_ok=True)
SERIES = {'gdp': ('NY.GDP.PCAP.PP.KD', 'gdppc'), 'gdi': ('NE.GDI.TOTL.ZS', 'gdi'), 'inf': ('FP.CPI.TOTL.ZG', 'inflation')}
for key, (code, col) in SERIES.items():
    d = wb.data.DataFrame(code, ISO, time=range(1996, 2025), numericTimeKeys=True).reset_index()
    d = d.melt(id_vars='economy', var_name='year', value_name=col).rename(columns={'economy': 'iso'}).dropna()
    d.to_csv(f'{OUT}/{key}_api.csv', index=False); print(key, len(d), 'rows')
# oil rents, % of GDP
d = wb.data.DataFrame('NY.GDP.PETR.RT.ZS', ISO, time=range(1996, 2025), numericTimeKeys=True).reset_index()
d = d.melt(id_vars='economy', var_name='year', value_name='oilrent').rename(columns={'economy': 'iso'}).dropna()
d.to_csv(f'{OUT}/oilrents.csv', index=False)
old = pd.read_csv('../data/oilrents.csv').merge(d, on=['iso', 'year'], suffixes=('_shipped', '_fresh'))
print('oil rents: max abs difference vs shipped file =', (old.oilrent_shipped - old.oilrent_fresh).abs().max())
# Brent, annual average (FRED POILBREUSDA)
raw = urllib.request.urlopen('https://fred.stlouisfed.org/graph/fredgraph.csv?id=POILBREUSDA').read().decode()
b = pd.read_csv(io.StringIO(raw)); b.columns = ['date', 'brent']; b['year'] = pd.to_datetime(b.date).dt.year
b[['year', 'brent']].to_csv(f'{OUT}/brent.csv', index=False)
old = pd.read_csv('../data/brent.csv').merge(b[['year', 'brent']], on='year', suffixes=('_shipped', '_fresh'))
print('Brent: max abs difference vs shipped file =', (old.brent_shipped - old.brent_fresh).abs().max())
