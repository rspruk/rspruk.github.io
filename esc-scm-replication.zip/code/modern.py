"""Modern synthetic-control estimators for one treated unit.

All estimators take a wide outcome matrix Y (T x N DataFrame, rows = years, columns = units,
treated unit first) and a treatment year t0, and return the counterfactual path for the treated unit.
Every tuning parameter is chosen by the same out-of-sample rule: fit on 1996-2007 and forecast the
treated unit over 2008-2011 (the last four pre-treatment years), unless t0 makes that window
unavailable, in which case the last quarter of the pre-period is held out.

Estimators
  sc        Abadie-Diamond-Hainmueller SC on pre-treatment outcomes (simplex weights)
  psc       Penalized SC, Abadie & L'Hour (2021, JASA)
  ascm      Ridge-augmented SC, Ben-Michael, Feller & Rothstein (2021, JASA)
  sdid      Synthetic difference-in-differences, Arkhangelsky et al. (2021, AER)
  mc        Matrix completion with nuclear-norm penalty and two-way FE, Athey et al. (2021, JASA)
  gsc       Generalized SC / interactive fixed effects, Xu (2017, Political Analysis)
  rsc       Robust SC (SVD denoising + ridge), Amjad, Shah & Shen (2018, JMLR)
  dsc       De-meaned SC, Ferman & Pinto (2021, QE); Doudchenko & Imbens (2016)
"""
import numpy as np, pandas as pd, cvxpy as cp
from scm import solve_w, polish


# ----------------------------------------------------------------- helpers
def _split(Y, t0):
    pre = [t for t in Y.index if t < t0]
    y1 = Y.iloc[:, 0].values.astype(float); Y0 = Y.iloc[:, 1:].values.astype(float)
    m = np.array([t in pre for t in Y.index])
    return y1, Y0, m


def _holdout(Y, t0):
    pre = [t for t in Y.index if t < t0]
    k = 4 if len(pre) >= 12 else max(2, len(pre) // 4)
    return pre[-k], pre  # holdout start year, pre years


def simplex_ls(a, A, ridge=0.0, intercept=False):
    """min ||a - (c) - A w||^2 + ridge*||w||^2, w in simplex (cvxpy)."""
    J = A.shape[1]; w = cp.Variable(J)
    c = cp.Variable() if intercept else 0
    obj = cp.sum_squares(a - c - A @ w) + ridge * cp.sum_squares(w)
    cp.Problem(cp.Minimize(obj), [w >= 0, cp.sum(w) == 1]).solve(solver=cp.CLARABEL)
    wv = np.clip(w.value, 0, None); wv = wv / wv.sum()
    return wv, (float(c.value) if intercept else 0.0)


def _tune(Y, t0, fit_fn, grid):
    """Pick the grid value minimising the 2008-11 forecast MSPE of the treated unit."""
    h, pre = _holdout(Y, t0)
    Ytr = Y.loc[[t for t in Y.index if t < h] + [t for t in pre if t >= h]]
    best, bv = None, np.inf
    for g in grid:
        cf = fit_fn(Ytr, h, g)
        err = Ytr.iloc[:, 0].loc[[t for t in pre if t >= h]].values - cf[[i for i, t in enumerate(Ytr.index) if t >= h]]
        mse = float(np.mean(err ** 2))
        if mse < bv - 1e-14:
            best, bv = g, mse
    return best


# ----------------------------------------------------------------- estimators
def sc(Y, t0, **k):
    y1, Y0, m = _split(Y, t0)
    w = solve_w(y1[m], Y0[m], np.ones(m.sum())); w = polish(y1[m], Y0[m], np.ones(m.sum()), w)
    return Y0 @ w, dict(w=w)


def _psc(Y, t0, lam):
    y1, Y0, m = _split(Y, t0)
    a, A = y1[m], Y0[m]
    d = ((A - a[:, None]) ** 2).sum(axis=0)          # pairwise discrepancy of each donor
    J = A.shape[1]; w = cp.Variable(J)
    cp.Problem(cp.Minimize(cp.sum_squares(a - A @ w) + lam * d @ w), [w >= 0, cp.sum(w) == 1]).solve(solver=cp.CLARABEL)
    wv = np.clip(w.value, 0, None); wv /= wv.sum()
    return Y0 @ wv, wv


def psc(Y, t0, grid=(0, 1e-4, 1e-3, 3e-3, 1e-2, 3e-2, 0.1, 0.3, 1.0), **k):
    lam = _tune(Y, t0, lambda Yy, tt, g: _psc(Yy, tt, g)[0], grid)
    cf, w = _psc(Y, t0, lam)
    return cf, dict(w=w, lam=lam)


def _ascm(Y, t0, lam):
    y1, Y0, m = _split(Y, t0)
    a, A = y1[m], Y0[m]                               # T0 x J
    w = solve_w(a, A, np.ones(len(a))); w = polish(a, A, np.ones(len(a)), w)
    X0 = A.T; mu = X0.mean(axis=0); X0c = X0 - mu; x1c = a - mu   # J x T0
    dlt = x1c - X0c.T @ w
    waug = w + X0c @ np.linalg.solve(X0c.T @ X0c + lam * np.eye(X0c.shape[1]), dlt)
    return Y0 @ waug, waug, w


def ascm(Y, t0, grid=None, **k):
    y1, Y0, m = _split(Y, t0)
    s = np.var(Y0[m]) * Y0.shape[1]
    grid = grid or [s * g for g in (1e-3, 1e-2, 0.03, 0.1, 0.3, 1, 3, 10, 100)]
    lam = _tune(Y, t0, lambda Yy, tt, g: _ascm(Yy, tt, g)[0], grid)
    cf, waug, w = _ascm(Y, t0, lam)
    return cf, dict(w=waug, w_sc=w, lam=lam)


def sdid(Y, t0, post_end=None, **k):
    """Arkhangelsky et al. (2021), Algorithm 1. Returns counterfactual such that gap_t =
    (y1t - sum w Y0t) - sum_s lam_s (y1s - sum w Y0s), i.e. the SDID event-time path."""
    y1, Y0, m = _split(Y, t0)
    post = ~m
    if post_end is not None:
        post = post & np.array([t <= post_end for t in Y.index])
    Tpre, Tpost, Nco = m.sum(), post.sum(), Y0.shape[1]
    dif = np.diff(Y0[m], axis=0)
    sigma = dif.std(ddof=1)
    zeta_w = (1 * Tpost) ** 0.25 * sigma
    zeta_l = 1e-6 * sigma
    # unit weights: intercept + simplex, ridge zeta^2 * Tpre
    w, _ = simplex_ls(y1[m], Y0[m], ridge=zeta_w ** 2 * Tpre, intercept=True)
    # time weights: regress control post means on control pre outcomes
    lam, _ = simplex_ls(Y0[post].mean(axis=0), Y0[m].T, ridge=zeta_l ** 2 * Nco, intercept=True)
    base_tr = lam @ y1[m]; base_co = lam @ (Y0[m] @ w)
    cf = Y0 @ w + (base_tr - base_co)              # counterfactual level for every year
    return cf, dict(w=w, lam=lam, zeta=zeta_w)


def _two_way(Yo, M):
    """Unit and time effects on observed entries (alternating means)."""
    a = np.zeros(Yo.shape[1]); b = np.zeros(Yo.shape[0])
    for _ in range(50):
        R = np.where(M, Yo - b[:, None], np.nan); a = np.nanmean(R, axis=0)
        R = np.where(M, Yo - a[None, :], np.nan); b = np.nanmean(R, axis=1)
    return a, b


def _mc(Y, t0, lam, iters=500):
    y1, Y0, m = _split(Y, t0)
    Yv = Y.values.astype(float); M = np.ones_like(Yv, bool); M[~m, 0] = False
    L = np.zeros_like(Yv)
    for _ in range(iters):
        a, b = _two_way(np.where(M, Yv - L, 0), M)
        FE = a[None, :] + b[:, None]
        Z = np.where(M, Yv - FE, L)
        U, s, Vt = np.linalg.svd(Z, full_matrices=False)
        s = np.maximum(s - lam, 0); Ln = (U * s) @ Vt
        if np.linalg.norm(Ln - L) < 1e-8 * (1 + np.linalg.norm(L)):
            L = Ln; break
        L = Ln
    a, b = _two_way(np.where(M, Yv - L, 0), M)
    return (L + a[None, :] + b[:, None])[:, 0]


def mc(Y, t0, grid=None, **k):
    y1, Y0, m = _split(Y, t0)
    s1 = np.linalg.svd(Y.values - Y.values.mean(), compute_uv=False)[0]
    grid = grid or [s1 * g for g in (1e-3, 3e-3, 0.01, 0.03, 0.1, 0.3)]
    lam = _tune(Y, t0, lambda Yy, tt, g: _mc(Yy, tt, g), grid)
    return _mc(Y, t0, lam), dict(lam=lam)


def _gsc(Y, t0, r):
    y1, Y0, m = _split(Y, t0)
    # interactive FE on controls: Y0 = alpha_j + xi_t + F Lambda' (iterative PCA)
    a = Y0.mean(axis=0); xi = (Y0 - a).mean(axis=1); R = Y0 - a[None, :] - xi[:, None]
    F = np.zeros((Y0.shape[0], 0))
    for _ in range(200):
        if r > 0:
            U, s, Vt = np.linalg.svd(R, full_matrices=False); F = U[:, :r] * s[:r]; Lc = Vt[:r].T
            C = F @ Lc.T
        else:
            C = 0
        Rn = Y0 - C
        a = (Rn - xi[:, None]).mean(axis=0); xi = (Rn - a[None, :]).mean(axis=1)
        R = Y0 - a[None, :] - xi[:, None]
    F = F / np.sqrt(Y0.shape[0]) if r > 0 else F
    # treated loadings from pre-period: y1 - xi = alpha1 + F lam1
    Xp = np.column_stack([np.ones(m.sum()), F[m]]) if r > 0 else np.ones((m.sum(), 1))
    coef = np.linalg.lstsq(Xp, y1[m] - xi[m], rcond=None)[0]
    Xall = np.column_stack([np.ones(len(y1)), F]) if r > 0 else np.ones((len(y1), 1))
    return xi + Xall @ coef


def gsc(Y, t0, grid=(0, 1, 2, 3, 4, 5), **k):
    r = _tune(Y, t0, lambda Yy, tt, g: _gsc(Yy, tt, g), grid)
    return _gsc(Y, t0, r), dict(r=r)


def _rsc(Y, t0, kk, ridge=1e-6):
    y1, Y0, m = _split(Y, t0)
    U, s, Vt = np.linalg.svd(Y0, full_matrices=False)
    Yd = (U[:, :kk] * s[:kk]) @ Vt[:kk]
    A = Yd[m]
    beta = np.linalg.solve(A.T @ A + ridge * np.trace(A.T @ A) / A.shape[1] * np.eye(A.shape[1]), A.T @ y1[m])
    return Yd @ beta


def rsc(Y, t0, grid=(1, 2, 3, 4, 5, 6), **k):
    kk = _tune(Y, t0, lambda Yy, tt, g: _rsc(Yy, tt, g), grid)
    return _rsc(Y, t0, kk), dict(k=kk)


def dsc(Y, t0, **k):
    y1, Y0, m = _split(Y, t0)
    mu1, mu0 = y1[m].mean(), Y0[m].mean(axis=0)
    w = solve_w(y1[m] - mu1, Y0[m] - mu0, np.ones(m.sum())); w = polish(y1[m] - mu1, Y0[m] - mu0, np.ones(m.sum()), w)
    return mu1 + (Y0 - mu0) @ w, dict(w=w)


ESTIMATORS = {'sc': sc, 'psc': psc, 'ascm': ascm, 'sdid': sdid, 'mc': mc, 'gsc': gsc, 'rsc': rsc, 'dsc': dsc}
LABELS = {'sc': 'Synthetic control (outcomes)', 'psc': 'Penalized SC', 'ascm': 'Augmented SC (ridge)',
          'sdid': 'Synthetic DiD', 'mc': 'Matrix completion', 'gsc': 'Generalized SC (IFE)',
          'rsc': 'Robust SC', 'dsc': 'De-meaned SC'}


def gap(Y, t0, est, **k):
    cf, info = ESTIMATORS[est](Y, t0, **k)
    return pd.Series(Y.iloc[:, 0].values - cf, index=Y.index), info
