"""Application robustness: in-time placebos around the 2008-09 oil collapse, backdating, leave-one-out.
Every exercise reports the SC and EASC estimates computed exactly as in the main analysis."""
import numpy as np, pandas as pd, pickle, warnings
warnings.filterwarnings('ignore')
from ebsc import exposure_effects, easc, sc_weights_fast, exposure_imbalance, donor_factors, partial_leverage
from app import P, O, BASE, EXT, X as XFULL, YEARS as YFULL

def wide(pool, y0=1996, y1=2024):
    Y = P[P.iso.isin(['IRN'] + pool) & P.year.between(y0, y1)].pivot(index='year', columns='iso', values='lgdppc')
    return Y[['IRN'] + pool]

def exposure(pool, a, b):
    s = O[O.year.between(a, b)].groupby('iso').oilrent.mean()
    return s.reindex(['IRN'] + pool).fillna(0.0)

def fit(Y, pool, s, t0):
    yrs = Y.index.values; pre = yrs < t0
    y1 = Y['IRN'].values; Y0 = Y[pool].values; s1 = float(s['IRN']); s0 = s[pool].values
    w = sc_weights_fast(y1[pre], Y0[pre]); g = y1 - Y0 @ w
    phi, se = exposure_effects(Y0, s0, pre, int(np.where(pre)[0][-1]))
    ge, ei = easc(y1, Y0, w, s1, s0, phi)
    return dict(years=yrs, g=g, ge=ge, ei=ei, w=w, phi=phi, se=se, rmspe=float(np.sqrt(np.mean(g[pre] ** 2))))

R = {}
# ---------------------------------------------------------------- 1. in-time placebos (sample ends 2011)
rows = []
for key, pool in [('base', BASE), ('ext', EXT)]:
    for t0 in (2006, 2007, 2008, 2009):
        Y = wide(pool, 1996, 2011); s = exposure(pool, 1996, t0 - 1)
        r = fit(Y, pool, s, t0); post = r['years'] >= t0
        win = (r['years'] >= 2009) & (r['years'] <= 2011)
        # leverage of the oil price in the placebo window relative to 1996..t0-1
        yrs = r['years']; Fl, _ = donor_factors(Y[pool].values, k=2, s=s[pool].values)
        xs = XFULL[np.isin(YFULL, yrs)]; pl, r2 = partial_leverage(xs, Fl, yrs < t0)
        rows.append(dict(pool=key, t0=t0, ei=r['ei'], rmspe=r['rmspe'],
                         sc_post=float(np.mean(r['g'][post])), easc_post=float(np.mean(r['ge'][post])),
                         sc_0911=float(np.mean(r['g'][win])), easc_0911=float(np.mean(r['ge'][win])),
                         sc_abs=float(np.mean(np.abs(r['g'][post]))), easc_abs=float(np.mean(np.abs(r['ge'][post]))),
                         plmax=float(np.max(np.abs(pl[yrs >= t0]))), r2=r2))
R['intime'] = pd.DataFrame(rows); print('In-time placebos (sample 1996-2011):'); print(R['intime'].round(3).to_string())

# ---------------------------------------------------------------- 2. backdating the treatment
PH = {'shock': (2012, 2015), 'relief': (2016, 2017), 'siege': (2018, 2024)}
rows = []
for key, pool in [('base', BASE), ('ext', EXT)]:
    for t0 in (2009, 2010, 2011, 2012):
        Y = wide(pool); s = exposure(pool, 1996, min(t0 - 1, 2011)); r = fit(Y, pool, s, t0)
        d = dict(pool=key, t0=t0, ei=r['ei'], rmspe=r['rmspe'])
        for ph, (a, b) in PH.items():
            m = (r['years'] >= a) & (r['years'] <= b)
            d[f'sc_{ph}'] = float(np.mean(r['g'][m])); d[f'easc_{ph}'] = float(np.mean(r['ge'][m]))
        m = (r['years'] >= t0) & (r['years'] < 2012)
        d['sc_pre12'] = float(np.mean(r['g'][m])) if m.any() else np.nan
        d['easc_pre12'] = float(np.mean(r['ge'][m])) if m.any() else np.nan
        rows.append(d)
R['backdate'] = pd.DataFrame(rows); print('\nBackdating:'); print(R['backdate'].round(3).to_string())

# ---------------------------------------------------------------- 3. leave-one-out
rows = []
for key, pool in [('base', BASE), ('ext', EXT)]:
    Y = wide(pool); s = exposure(pool, 1996, 2011); r0 = fit(Y, pool, s, 2012)
    for j in [pool[i] for i in np.argsort(-r0['w']) if r0['w'][i] > 0.01]:
        pl_ = [d for d in pool if d != j]; r = fit(Y[['IRN'] + pl_], pl_, s, 2012)
        d = dict(pool=key, dropped=j, weight=float(r0['w'][pool.index(j)]), ei=r['ei'], rmspe=r['rmspe'])
        for ph, (a, b) in PH.items():
            m = (r['years'] >= a) & (r['years'] <= b)
            d[f'sc_{ph}'] = float(np.mean(r['g'][m])); d[f'easc_{ph}'] = float(np.mean(r['ge'][m]))
        rows.append(d)
R['loo'] = pd.DataFrame(rows); print('\nLeave-one-out:'); print(R['loo'].round(3).to_string())
pickle.dump(R, open('../results/app_robust.pkl', 'wb'))
