"""Monte Carlo calibrated to the Iran application (Section 5 of the paper).

DGP (untreated outcomes), years 1996-2024, treatment from 2012:
    Y_jt = a_j + d_t + theta_j * x_t + mu_j * f_t + nu_j * h_t + e_jt
    x_t   observed common shock: log Brent (actual path), centred on its 1996-2011 mean
    f_t   latent trend (decades from 2003.5); x_t is nearly collinear with f_t before 2012
    h_t   latent random walk, innovation s.d. 0.03, redrawn each replication
    theta_j = gamma * s_j (linear exposure), s_j = 1996-2011 oil rents (% of GDP) of the donor pool
    mu_j  = xi_j - gamma * b * s_j: donors' composite pre-period trend loading (mu_j + gamma*b*s_j) does
          not depend on exposure, so pre-treatment fit cannot reveal exposure (b = slope of x on f pre-2012)
    e_jt  AR(1), rho = 0.5, marginal s.d. 0.015
Treated unit: s_1 = 22.87 (Iran), xi_1 = nu_1 = a_1 = 0. Effect: -0.10 in 2012-15, -0.05 afterwards.

Scenarios
    S0 no exposure channel (gamma = 0)
    S1 in-span shock: post-2012 x_t follows its pre-2012 relation with f_t
    S2 baseline: actual Brent, treated outside the donors' exposure hull (19 donors, max s = 16.56)
    S3 actual Brent, treated inside the hull (21 donors: adds s = 26.52 and 38.42)
    S4 as S2, exposure observed with multiplicative error (log s.d. 0.3)
    S5 as S2, concave exposure: theta_j = gamma * c * (1 - exp(-s_j / c)), c = 20; estimators use linear s
    S6 as S5 with the 21-donor pool (treated inside the support of the exposure regression)
    S7 as S2 with 38 donors (each of the 19 exposure values twice, loadings drawn independently)
    S8 21 donors, composite trend loadings correlated with exposure (xi_j = N(0,0.08) + 0.004 (s_j - mean s)):
       Assumption 3 fails because growth controls cannot separate the exposure-related part of the loading
    S9 21 donors, latent random walk innovation s.d. rises from 0.03 to 0.30 after 2014: high latent leverage, as in the application
    S10 S8 + S9 with the treated unit's trend loading at the top of the donor distribution (0.16 = 2 s.d.)
    S11 21 donors, a second unobserved shock z_t (0 before 2015, -1 by 2024) with loadings 0.004 s_j + N(0,0.03);
        the treated unit's loading is 0.06 above what its exposure predicts: no estimator can recover this
"""
import numpy as np, pandas as pd, pickle, sys, time, warnings
from multiprocessing import Pool
warnings.filterwarnings('ignore')
sys.path.insert(0, '.')
from ebsc import (leverage_sc, leverage_easc, donor_factors, shock_leverage, phase_leverage, partial_leverage, exposure_effects, easc,
                  exposure_imbalance, sc_weights_fast, frontier_path, easc_select, cv_bias_aware, min_imbalance)
import modern

YEARS = np.arange(1996, 2025); T = len(YEARS); PRE = YEARS < 2012; POST = ~PRE; BASEIDX = list(YEARS).index(2011)
PH = {'shock': (2012, 2015), 'relief': (2016, 2017), 'siege': (2018, 2024)}
PHM = {k: (YEARS >= a) & (YEARS <= b) for k, (a, b) in PH.items()}
TAU = np.where(YEARS < 2012, 0.0, np.where(YEARS <= 2015, -0.10, -0.05))
Br = pd.read_csv('../data/brent.csv').set_index('year').brent
XR = np.log(Br.loc[YEARS].values); XR = XR - XR[PRE].mean()
F1 = (YEARS - 2003.5) / 10.0
_b = np.polyfit(F1[PRE], XR[PRE], 1); BSLOPE = _b[0]
X_INSPAN = np.where(PRE, XR, np.polyval(_b, F1))           # S1: post-2012 x on its pre-2012 trend
O = pd.read_csv('../data/oilrents.csv')
S_ALL = O[O.year.between(1996, 2011)].groupby('iso').oilrent.mean()
BASE = ['KAZ', 'NGA', 'ECU', 'MEX', 'COL', 'JOR', 'ROU', 'BGR', 'VNM', 'ZAF', 'PHL', 'THA', 'KEN', 'BRA', 'CHL', 'PER', 'CRI', 'DOM', 'PAN']
S_BASE = S_ALL.reindex(BASE).fillna(0.0).values
S_EXT = S_ALL.reindex(BASE + ['AZE', 'AGO']).fillna(0.0).values
S1_TREATED = float(S_ALL['IRN'])
GAMMA = 0.008
SCEN = {
    'S0': dict(gamma=0.0, x=XR, s0=S_BASE, noise=0.0, concave=False, label='No exposure channel'),
    'S1': dict(gamma=GAMMA, x=X_INSPAN, s0=S_BASE, noise=0.0, concave=False, label='In-span common shock'),
    'S2': dict(gamma=GAMMA, x=XR, s0=S_BASE, noise=0.0, concave=False, label='Out-of-span, outside hull (baseline)'),
    'S3': dict(gamma=GAMMA, x=XR, s0=S_EXT, noise=0.0, concave=False, label='Out-of-span, inside hull'),
    'S4': dict(gamma=GAMMA, x=XR, s0=S_BASE, noise=0.3, concave=False, label='Exposure measured with error'),
    'S5': dict(gamma=GAMMA, x=XR, s0=S_BASE, noise=0.0, concave=True, label='Concave exposure, outside hull'),
    'S6': dict(gamma=GAMMA, x=XR, s0=S_EXT, noise=0.0, concave=True, label='Concave exposure, inside hull'),
    'S7': dict(gamma=GAMMA, x=XR, s0=np.r_[S_BASE, S_BASE], noise=0.0, concave=False, label='Baseline with 38 donors'),
    'S8': dict(gamma=GAMMA, x=XR, s0=S_EXT, noise=0.0, concave=False, corr=True, label='Loadings correlated with exposure'),
    'S9': dict(gamma=GAMMA, x=XR, s0=S_EXT, noise=0.0, concave=False, latent_break=True, label='Latent break after 2014 (high latent leverage)'),
    'S10': dict(gamma=GAMMA, x=XR, s0=S_EXT, noise=0.0, concave=False, corr=True, latent_break=True, treated_out=True, label='S8 + S9, treated outside latent hull'),    'S11': dict(gamma=GAMMA, x=XR, s0=S_EXT, noise=0.0, concave=False, hidden=True, label='Unobserved out-of-span shock, treated-specific loading'),
}
EST = ['SC', 'ASCM', 'SDID', 'DSC', 'GSC', 'MC', 'EBSC-min', 'EASC', 'EASC*']
MS = (0.0, 0.5, 1.0)


def draw(scn, rng):
    p = SCEN[scn]; s0 = p['s0']; J = len(s0); x = p['x']
    s = np.r_[S1_TREATED, s0]
    theta = p['gamma'] * (20 * (1 - np.exp(-s / 20)) if p['concave'] else s)
    xi = np.r_[0.0, rng.normal(0, 0.08, J)]
    if p.get('corr'):                       # composite loadings depend on exposure: Assumption 3 fails for the
        xi = xi + 0.004 * (s - s.mean())    # part of mu that growth controls cannot separate from exposure
    if p.get('treated_out'):
        xi[0] = 0.16                        # treated unit's latent trend loading at the edge of the donor distribution
    mu = xi - p['gamma'] * BSLOPE * s if not p['concave'] else xi - BSLOPE * theta
    nu = np.r_[0.0, rng.normal(0, 1.0, J)]
    a = np.r_[0.0, rng.normal(0, 0.3, J)]
    sd_h = np.where(YEARS >= 2015, 0.3, 0.03) if p.get('latent_break') else np.full(T, 0.03)
    h = np.cumsum(rng.normal(0, 1.0, T) * sd_h); h -= h[PRE].mean()
    e = np.zeros((T, J + 1)); sd_u = 0.015 * np.sqrt(1 - 0.25)
    e[0] = rng.normal(0, 0.015, J + 1)
    for t in range(1, T):
        e[t] = 0.5 * e[t - 1] + rng.normal(0, sd_u, J + 1)
    d = 0.02 * (YEARS - 1996)
    Y = a[None, :] + d[:, None] + np.outer(x, theta) + np.outer(F1, mu) + np.outer(h, nu) + e
    if p.get('hidden'):                     # second, unobserved out-of-span shock z_t (zero before 2015, falling to -1 by 2024)
        z = np.where(YEARS >= 2015, -(YEARS - 2014) / 10.0, 0.0)
        zeta = 0.004 * s + rng.normal(0, 0.03, J + 1)     # loadings tied to exposure (recoverable by the regression)...
        zeta[0] = 0.004 * s[0] + 0.06                      # ...except the treated unit, whose loading is 2 s.d. above
        Y = Y + np.outer(z, zeta)
    Y[:, 0] += TAU
    s_obs = s * np.exp(rng.normal(0, p['noise'], J + 1)) if p['noise'] > 0 else s.copy()
    # true out-of-span component of x relative to the latent factors (for reporting)
    return Y, s_obs, dict(theta=theta, mu=mu, nu=nu, h=h)


def run_unit(y1, Y0, s1, s0, keep_w=False):
    w = sc_weights_fast(y1[PRE], Y0[PRE]); g = y1 - Y0 @ w
    phi, se = exposure_effects(Y0, s0, PRE, BASEIDX)
    ge, ei = easc(y1, Y0, w, s1, s0, phi)
    F, _ = donor_factors(Y0, k=2); G = np.column_stack([np.ones(T), F])
    Fl, _ = donor_factors(Y0, k=2, s=s0); Gl = np.column_stack([np.ones(T), Fl])
    rm = float(np.sqrt(np.mean(g[PRE] ** 2)))
    out = dict(g=g, ge=ge, ei=ei, se=se, phi=phi, G=G, Gl=Gl, rmspe=rm, F=F, Fl=Fl)
    if keep_w:
        out['w'] = w
    return out


def pm(v):
    return {k: float(np.mean(v[m])) for k, m in PHM.items()}


def one_rep(args):
    scn, rep, seed = args
    rng = np.random.default_rng(seed)
    Y, s, info = draw(scn, rng)
    y1, Y0, s1, s0 = Y[:, 0], Y[:, 1:], float(s[0]), s[1:]
    J = Y0.shape[1]
    df = pd.DataFrame(Y, index=YEARS, columns=['T'] + [f'D{j:02d}' for j in range(J)])
    gaps = {}
    tr = run_unit(y1, Y0, s1, s0, keep_w=True)
    gaps['SC'] = tr['g']; gaps['EASC'] = tr['ge']
    for nm, fn in [('ASCM', 'ascm'), ('SDID', 'sdid'), ('DSC', 'dsc'), ('GSC', 'gsc')]:
        cf, _ = modern.ESTIMATORS[fn](df, 2012)
        gaps[nm] = y1 - cf
    lam = 0.01 * np.linalg.svd(Y - Y.mean(), compute_uv=False)[0]
    gaps['MC'] = y1 - modern._mc(df, 2012, lam, iters=300)
    kap_l = shock_leverage(tr['Gl'], PRE)
    path = frontier_path(y1, Y0, PRE, s1, s0, n=21, w_sc=tr['w'])
    gaps['EBSC-min'] = y1 - Y0 @ path[0]['w']
    best = easc_select(path, kap_l, tr['se'], POST)
    gaps['EASC*'], ei_star = easc(y1, Y0, best['w'], s1, s0, tr['phi'])
    err = {e: {k: v - float(np.mean(TAU[PHM[k]])) for k, v in pm(gaps[e]).items()} for e in EST}
    # ---------------- inference for SC and EASC (placebos + leverage-based bias bound)
    plac = [run_unit(Y0[:, j], np.delete(Y0, j, 1), float(s0[j]), np.delete(s0, j)) for j in range(J)]
    inf = {}; xs = SCEN[scn]['x']
    for est, gk, Gk in [('SC', 'g', 'G'), ('EASC', 'ge', 'Gl')]:
        for ph, m in PHM.items():
            tau_hat = float(np.mean(tr[gk][m])); truth = float(np.mean(TAU[m]))
            z = np.array([np.mean(p[gk][m]) / p['rmspe'] for p in plac])
            sd = float(z.std(ddof=1) * tr['rmspe'])
            if est == 'EASC':
                sd = float(np.sqrt(sd ** 2 + (abs(tr['ei']) * np.mean(tr['se'][m])) ** 2))
            sdm = float(1.4826 * np.median(np.abs(z - np.median(z))) * tr['rmspe'])   # robust (MAD) variant
            if est == 'EASC':
                sdm = float(np.sqrt(sdm ** 2 + (abs(tr['ei']) * np.mean(tr['se'][m])) ** 2))
            kb = leverage_sc(xs, tr['Fl'], PRE, m) if est == 'SC' else leverage_easc(xs, tr['Fl'], PRE, m, BASEIDX)
            for M in MS:
                for nm, s_ in (('', sd), ('mad', sdm)):
                    hw = cv_bias_aware(M * kb * tr['rmspe'] / s_) * s_
                    inf[(est + nm, ph, M)] = (abs(tau_hat - truth) <= hw, 2 * hw)
            inf[(est, ph, 'kbar')] = kb; inf[(est, ph, 'sd')] = sd
            # placebo rank test of the null of no effect (power / size)
            stat = abs(tau_hat) / tr['rmspe']
            inf[(est, ph, 'rank')] = (1 + sum(abs(np.mean(p[gk][m])) / p['rmspe'] >= stat for p in plac)) / (J + 1)
    pl, r2 = partial_leverage(SCEN[scn]['x'], tr['Fl'], PRE)
    diag = dict(ei_sc=tr['ei'], ei_min=path[0]['ei'], ei_star=ei_star, rmspe=tr['rmspe'], rmspe_min=path[0]['rmspe'],
                frac=best['frac'], r2=r2, plmax=float(np.max(np.abs(pl[POST]))), dmin=min_imbalance(s1, s0))
    return dict(scn=scn, rep=rep, err=err, inf=inf, diag=diag)


if __name__ == '__main__':
    R = int(sys.argv[1]) if len(sys.argv) > 1 else 500
    scns = sys.argv[2].split(',') if len(sys.argv) > 2 else list(SCEN)
    jobs = [(sc, r, 20261002 + 1000 * i + r) for i, sc in enumerate(SCEN) if sc in scns for r in range(R)]
    t = time.time()
    with Pool(2) as P:
        res = P.map(one_rep, jobs, chunksize=5)
    print(f'{len(jobs)} replications in {time.time() - t:.0f}s')
    tag = sys.argv[3] if len(sys.argv) > 3 else 'mc'
    pickle.dump(res, open(f'../results/{tag}.pkl', 'wb'))
