"""Figures and LaTeX tables for the application (Section 6 and Online Appendix)."""
import numpy as np, pandas as pd, pickle, os, json, warnings
warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from ebsc import (donor_factors, shock_leverage, partial_leverage, leverage_sc, leverage_easc, cv_bias_aware,
                  breakdown_M, exposure_imbalance)
from app import wide, BASE, EXT, YEARS, PRE, PH, S_RENTS, X, P

OUT = '../paper'; os.makedirs(f'{OUT}/figures', exist_ok=True); os.makedirs(f'{OUT}/tables', exist_ok=True)
R = pickle.load(open('../results/app_main.pkl', 'rb'))
I = pickle.load(open('../results/app_inference.pkl', 'rb'))
RB = pickle.load(open('../results/app_robust.pkl', 'rb'))
PHI = json.load(open('../results/phi_phase.json'))
plt.rcParams.update({'font.family': 'serif', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.titlesize': 9.5, 'legend.fontsize': 8, 'legend.frameon': False, 'figure.dpi': 150})
C = dict(sc='0.35', easc='#1f4e9c', easc_b='#7aa6d9', ebsc='#d9822b', iran='black', plac='0.82')
NAMES = dict(KAZ='Kazakhstan', NGA='Nigeria', ECU='Ecuador', MEX='Mexico', COL='Colombia', JOR='Jordan', ROU='Romania',
             BGR='Bulgaria', VNM='Vietnam', ZAF='South Africa', PHL='Philippines', THA='Thailand', KEN='Kenya', BRA='Brazil',
             CHL='Chile', PER='Peru', CRI='Costa Rica', DOM='Dominican Rep.', PAN='Panama', AZE='Azerbaijan', AGO='Angola', IRN='Iran')
B11 = list(YEARS).index(2011)
PHM = {k: (YEARS >= a) & (YEARS <= b) for k, (a, b) in PH.items()}


def shade(ax):
    for (a, b), c in zip(PH.values(), ['0.88', '0.95', '0.88']):
        ax.axvspan(a - 0.5, b + 0.5, color=c, lw=0, zorder=0)
    ax.axvline(2011.5, color='0.4', lw=0.6, ls=':')


def f3(v, d=3):
    return '--' if v is None or (isinstance(v, float) and np.isnan(v)) else f'{v:+.{d}f}'.replace('+', '') if v >= 0 else f'$-${abs(v):.{d}f}'


def num(v, d=3, sign=True):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return '--'
    s = f'{abs(v):.{d}f}'
    return (f'$-${s}' if v < 0 else s) if sign else s


def ci(c, d=2):
    return f'[{num(c[0], d)}, {num(c[1], d)}]'


# ------------------------------------------------------------------ common objects
Yb = wide(BASE); Ye = wide(EXT); y1 = Yb['IRN'].values
b, e = R['base'], R['ext']
Fl_b = donor_factors(Yb[BASE].values, 2, s=S_RENTS[BASE].values)[0]
Fl_e = donor_factors(Ye[EXT].values, 2, s=S_RENTS[EXT].values)[0]

# ------------------------------------------------------------------ Figure 1: motivation
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.8))
a = ax[0]; shade(a)
a.plot(YEARS, y1, color=C['iran'], lw=1.6, label='Iran')
a.plot(YEARS, y1 - b['g_sc'], color=C['sc'], lw=1.3, ls='--', label='Synthetic control')
a.plot(YEARS, y1 - e['g_easc'], color=C['easc'], lw=1.3, label='Exposure-augmented SC')
a.set_ylabel('log GDP per capita (PPP)'); a.set_title('(a) Iran and two counterfactuals'); a.legend(loc='upper left')
a = ax[1]; shade(a)
Xd = np.column_stack([np.ones(len(YEARS)), Fl_b]); cf = np.linalg.lstsq(Xd[PRE], X[PRE], rcond=None)[0]
a.plot(YEARS, X, color='black', lw=1.5, label='log Brent price (observed)')
a.plot(YEARS, Xd @ cf, color=C['easc'], ls='--', lw=1.3, label='Projection on latent factors\n(fitted 1996--2011)'.replace('--', '–'))
a.set_ylabel('log US\\$ per barrel'.replace('\\', '')); a.set_title('(b) Oil leaves its pre-treatment span'); a.legend(loc='upper left')
for a in ax:
    a.set_xlim(1995.5, 2024.5)
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig1_motivation.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Figure 2: leverage diagnostics
G = np.column_stack([np.ones(len(YEARS)), Fl_b, X]); Gl = np.column_stack([np.ones(len(YEARS)), Fl_b])
kap = shock_leverage(G, PRE); kapl = shock_leverage(Gl, PRE); ell, r2 = partial_leverage(X, Fl_b, PRE)
fig, ax = plt.subplots(1, 2, figsize=(7.2, 2.7))
a = ax[0]; shade(a)
a.bar(YEARS, ell, color=np.where(PRE, '0.55', C['easc']), width=0.7)
a.axhline(2, color='0.3', lw=0.6, ls='--'); a.axhline(-2, color='0.3', lw=0.6, ls='--'); a.axhline(0, color='0.3', lw=0.5)
a.set_title(f'(a) Partial leverage of oil, $\\ell_t$ (pre-period $R^2$ = {r2:.2f})'); a.set_xlim(1995.5, 2024.5)
a = ax[1]; shade(a)
a.plot(YEARS, kap, color='black', lw=1.5, label=r'$\kappa_t$: oil and latent factors')
a.plot(YEARS, kapl, color=C['easc'], lw=1.3, ls='--', label=r'$\kappa^{\lambda}_t$: latent factors only')
a.axhline(np.sqrt(4), color='0.4', lw=0.6, ls=':'); a.text(1996, 3.2, r'$\sqrt{p}=2$', fontsize=8, color='0.3')
a.set_title('(b) Leverage of the common factors'); a.legend(loc='upper left'); a.set_xlim(1995.5, 2024.5)
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig2_leverage.pdf'); plt.close(fig)
LEV = dict(r2=r2, ell=dict(zip(YEARS.tolist(), ell.tolist())), kap=dict(zip(YEARS.tolist(), kap.tolist())),
           kapl=dict(zip(YEARS.tolist(), kapl.tolist())), pre_k2=float(np.mean(kap[PRE] ** 2)))

# ------------------------------------------------------------------ Figure 3: exposure geometry
fig, ax = plt.subplots(figsize=(5.4, 3.3))
Ye2 = wide(EXT); gpre = 100 * (Ye2.loc[2011] - Ye2.loc[1996]) / 15
w = pd.Series(b['w_sc'], index=BASE)
ax.axvspan(S_RENTS[BASE].max(), 40, color='0.93', lw=0, zorder=0)
ax.text(S_RENTS[BASE].max() + 0.6, 8.6, 'outside the exposure hull\nof the 19 normalisers', fontsize=7.5, color='0.35', va='bottom')
for j in BASE:
    ax.scatter(S_RENTS[j], gpre[j], s=20 + 900 * w[j], color=C['easc'] if w[j] > 0.01 else '0.6', alpha=0.85, edgecolor='white', lw=0.5, zorder=3)
    if w[j] > 0.01 or S_RENTS[j] > 10:
        ax.annotate(NAMES[j], (S_RENTS[j], gpre[j]), xytext=(4, 3), textcoords='offset points', fontsize=7)
for j in ['AZE', 'AGO']:
    ax.scatter(S_RENTS[j], gpre[j], s=30, facecolor='white', edgecolor=C['ebsc'], lw=1.2, zorder=3)
    ax.annotate(NAMES[j], (S_RENTS[j], gpre[j]), xytext=(4, 3), textcoords='offset points', fontsize=7, color=C['ebsc'])
s_syn = float(S_RENTS[BASE].values @ b['w_sc']); g_syn = float(gpre[BASE].values @ b['w_sc'])
ax.scatter(S_RENTS['IRN'], gpre['IRN'], marker='*', s=160, color='black', zorder=4)
ax.annotate('Iran', (S_RENTS['IRN'], gpre['IRN']), xytext=(5, -10), textcoords='offset points', fontsize=8)
ax.scatter(s_syn, g_syn, marker='D', s=40, color=C['sc'], zorder=4)
ax.annotate('synthetic Iran', (s_syn, g_syn), xytext=(0, 9), textcoords='offset points', fontsize=8, ha='center')
ax.annotate('', xy=(S_RENTS['IRN'], gpre['IRN']), xytext=(s_syn, g_syn), arrowprops=dict(arrowstyle='<->', color='0.3', lw=0.8))
ax.text(19.5, (g_syn + gpre['IRN']) / 2 + 0.25, f'EI = {b["ei_sc"]:.1f} pp', fontsize=8, ha='center')
ax.set_xlabel('Oil exposure $s_j$: oil rents, % of GDP, 1996–2011 mean'); ax.set_ylabel('Growth 1996–2011, % per year')
ax.set_xlim(-1, 40)
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig3_exposure.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Figure 4: exposure-fit frontier
fig, ax = plt.subplots(figsize=(4.6, 3.0))
for r_, lab, col in [(b, 'Normalisers (19)', C['sc']), (e, 'Exposure-feasible (21)', C['easc'])]:
    pts = sorted([(abs(p['ei']), p['rmspe']) for p in r_['path']])
    ax.plot([p[0] for p in pts], [p[1] for p in pts], color=col, lw=1.5, marker='o', ms=2.5, label=lab)
ax.scatter([abs(b['ei_sc'])], [b['rmspe_sc']], marker='D', color='black', zorder=4, s=30)
ax.annotate('SC', (abs(b['ei_sc']), b['rmspe_sc']), xytext=(-4, 6), textcoords='offset points', fontsize=8, ha='right')
ax.annotate('EBSC-min\n(normalisers)', (abs(b['path'][0]['ei']), b['path'][0]['rmspe']), xytext=(-6, -8), textcoords='offset points', fontsize=7.5, ha='right')
ax.annotate('EBSC-min\n(exposure-feasible)', (0, e['path'][0]['rmspe']), xytext=(6, 6), textcoords='offset points', fontsize=7.5)
ax.axvline(b['dmin'], color='0.5', lw=0.6, ls=':'); ax.text(b['dmin'] - 0.25, 0.016, r'$d_{\min}$', fontsize=8, color='0.3', ha='right')
ax.set_yscale('log'); ax.set_xlabel('Exposure imbalance |EI(w)|, pp of GDP'); ax.set_ylabel('Pre-treatment RMSPE')
ax.legend(loc='upper right', bbox_to_anchor=(1.0, 0.75))
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig4_frontier.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Figure 5: exposure effects phi_t
fig, ax = plt.subplots(figsize=(4.8, 2.9)); shade(ax)
for r_, lab, col, off in [(b, 'Normalisers (19)', C['sc'], -0.12), (e, 'Exposure-feasible (21)', C['easc'], 0.12)]:
    m = YEARS >= 2012
    ax.errorbar(YEARS[m] + off, 100 * r_['phi'][m], yerr=196 * r_['se_phi'][m], fmt='o', ms=3, color=col, lw=0.9, capsize=0, label=lab)
ax.axhline(0, color='0.3', lw=0.6)
ax.set_xlim(2011, 2024.7); ax.set_ylabel(r'$100\times\hat\phi_t$ (log points per pp)')
ax.set_title(r'Cross-donor effect of oil exposure on $Y_{jt}-Y_{j,2011}$'); ax.legend(loc='lower left')
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig5_phi.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Figure 6: gaps and phase estimates
Te, Tb = I['ext']['table'], I['base']['table']; res_e = I['ext']['res']
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0), gridspec_kw=dict(width_ratios=[1.35, 1]))
a = ax[0]; shade(a)
for u, r_ in res_e.items():
    if u != 'IRN' and r_['rmspe'] ** 2 <= 5 * res_e['IRN']['rmspe'] ** 2:
        a.plot(YEARS, r_['ge'], color=C['plac'], lw=0.6, zorder=1)
a.plot(YEARS, b['g_sc'], color=C['sc'], ls='--', lw=1.3, label='SC')
a.plot(YEARS, e['g_ebsc_min'], color=C['ebsc'], lw=1.2, label='EBSC-min')
a.plot(YEARS, e['g_easc'], color=C['easc'], lw=1.6, label='EASC')
a.axhline(0, color='0.3', lw=0.6); a.set_xlim(1995.5, 2024.5); a.set_ylim(-0.45, 0.45)
a.set_title('(a) Gaps; grey: EASC placebo gaps'); a.legend(loc='lower left', ncol=3)
a = ax[1]
ph = list(PH)
for k, (est, col, T_) in enumerate([('SC', C['sc'], Te), ('EASC', C['easc'], Te)]):
    for i, p in enumerate(ph):
        r_ = T_[(T_.est == est) & (T_.phase == p)].iloc[0]; yv = 2 - i + (0.15 if k == 0 else -0.15)
        a.plot(r_.ci05, [yv, yv], color=col, lw=0.8); a.plot(r_.ci0, [yv, yv], color=col, lw=2.6, solid_capstyle='butt')
        a.scatter([r_.tau], [yv], color='white', edgecolor=col, zorder=3, s=18, lw=1.2)
a.axvline(0, color='0.3', lw=0.6); a.set_yticks([2, 1, 0]); a.set_yticklabels(['2012–15', '2016–17', '2018–24']); a.set_ylim(-0.6, 2.9)
a.plot([], [], color=C['sc'], lw=2.6, label='SC'); a.plot([], [], color=C['easc'], lw=2.6, label='EASC'); a.legend(loc='upper right', ncol=2)
a.set_title('(b) 95% CI: M = 0 (thick), M = 0.5 (thin)'); a.set_xlabel('log points')
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig6_gaps.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Figure 7: sensitivity in M
Ms = np.linspace(0, 1, 101)
fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.6), sharey=True)
for i, p in enumerate(ph):
    a = ax[i]
    for est, col in [('SC', C['sc']), ('EASC', C['easc'])]:
        r_ = Te[(Te.est == est) & (Te.phase == p)].iloc[0]
        hw = np.array([cv_bias_aware(M * r_.kbar * r_.rmspe / r_.sd) * r_.sd for M in Ms])
        a.fill_between(Ms, r_.tau - hw, r_.tau + hw, color=col, alpha=0.22, lw=0)
        a.plot(Ms, r_.tau - hw, color=col, lw=0.9); a.plot(Ms, r_.tau + hw, color=col, lw=0.9, label=est)
        if r_.Mstar > 0:
            a.axvline(r_.Mstar, color=col, lw=0.8, ls=':'); a.text(r_.Mstar + 0.02, 0.45 if est == 'SC' else 0.3, f'$M^*$={r_.Mstar:.2f}', color=col, fontsize=7.5)
    a.axhline(0, color='0.3', lw=0.6); a.set_title(['(a) 2012–15', '(b) 2016–17', '(c) 2018–24'][i]); a.set_xlabel('M')
    a.set_ylim(-0.6, 0.6)
ax[0].set_ylabel('95% bias-aware CI'); ax[0].legend(loc='lower left')
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig7_sensitivity.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Figure 8: estimators before/after exposure adjustment
EI = R['EI']['ext']; lab = dict(sc='SC', psc='Penalized SC', ascm='Augmented SC', sdid='Synthetic DiD', dsc='De-meaned SC',
                                mc='Matrix completion', gsc='Generalized SC', rsc='Robust SC')
order = ['sc', 'psc', 'ascm', 'sdid', 'dsc', 'mc', 'gsc', 'rsc']
fig, ax = plt.subplots(1, 3, figsize=(7.4, 2.9), sharey=True)
for i, p in enumerate(ph):
    a = ax[i]
    for k, est in enumerate(order):
        y_ = len(order) - k; g0 = EI.loc[est, f'g_{p}']; g1 = EI.loc[est, f'ea_{p}']
        a.scatter([g0], [y_], color=C['sc'], s=16, zorder=3)
        if not np.isnan(g1):
            a.annotate('', xy=(g1, y_), xytext=(g0, y_), arrowprops=dict(arrowstyle='->', color=C['easc'], lw=1.0))
            a.scatter([g1], [y_], color=C['easc'], s=16, zorder=3)
    a.axvline(0, color='0.3', lw=0.6); a.set_title(['(a) 2012–15', '(b) 2016–17', '(c) 2018–24'][i]); a.set_xlabel('log points')
ax[0].set_yticks(range(len(order), 0, -1)); ax[0].set_yticklabels([lab[o] for o in order])
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig8_estimators.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Table: diagnostics
def diag_cols(r_, Fl, pool, key):
    ell_, r2_ = partial_leverage(X, Fl, PRE)
    d = {'Treated exposure $s_1$': f"{r_['s1']:.2f}", 'Donor exposure range': f"[{r_['s0'].min():.2f}, {r_['s0'].max():.2f}]",
         r'Distance to hull $d_{\min}$': f"{r_['dmin']:.2f}", 'Exposure imbalance of SC, EI($\\hat w$)': f"{r_['ei_sc']:.2f}",
         'Pre-treatment RMSPE of SC': f"{r_['rmspe_sc']:.4f}", r'RMSPE at $d_{\min}$ (EBSC-min)': f"{r_['rmspe_min']:.4f}",
         r'$R^2$ of oil on latent factors, 1996--2011': f"{r2_:.3f}",
         r'$\max_{t\le 2011}|\ell_t|$': f"{np.max(np.abs(ell_[PRE])):.2f}", r'$\max_{t\ge 2012}|\ell_t|$': f"{np.max(np.abs(ell_[~PRE])):.2f}"}
    for p, m in PHM.items():
        d[rf'$\kappa$ (SC), {PH[p][0]}--{PH[p][1]}'] = f"{leverage_sc(X, Fl, PRE, m):.2f}"
    for p, m in PHM.items():
        d[rf'$\kappa$ (EASC), {PH[p][0]}--{PH[p][1]}'] = f"{leverage_easc(X, Fl, PRE, m, B11):.2f}"
    return d
D = pd.DataFrame({'Normalisers (19)': diag_cols(b, Fl_b, BASE, 'base'), 'Exposure-feasible (21)': diag_cols(e, Fl_e, EXT, 'ext')})
with open(f'{OUT}/tables/tab_diagnostics.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Diagnostics for out-of-span exposure}\\label{tab:diag}\n')
    f.write('\\begin{tabular}{@{}lcc@{}}\\toprule\n & Normalisers (19) & Exposure-feasible (21)\\\\\\midrule\n')
    for i, (k, row) in enumerate(D.iterrows()):
        if i in (0, 6, 9):
            f.write(['\\multicolumn{3}{@{}l}{\\emph{Exposure geometry}}\\\\\n', '\\multicolumn{3}{@{}l}{\\emph{Partial leverage of the oil price}}\\\\\n',
                     '\\multicolumn{3}{@{}l}{\\emph{Leverage of phase averages}}\\\\\n'][(0, 6, 9).index(i)])
        f.write(f'\\quad {k} & {row.iloc[0]} & {row.iloc[1]}\\\\\n')
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.92\\textwidth}\\footnotesize\\emph{Notes.} Exposure is the 1996--2011 mean of oil rents in percent of GDP (WDI). '
            'EI is the treated unit\'s exposure minus the weighted donor average. Latent factors: two principal components of two-way demeaned donor outcomes after removing, period by period, the cross-sectional projection on exposure. '
            '$\\ell_t$ is the residual of log Brent on a constant and the latent factors (fitted 1996--2011), divided by its pre-treatment root mean square (Corollary~\\ref{cor:fwl}). '
            '$\\kappa$ for a phase is the leverage of the phase-averaged factor vector (Proposition~\\ref{prop:leverage}); the pre-treatment average of $\\kappa_t^2$ equals the number of factors including the constant (4 for SC, 3 for the latent block). '
            'The EASC leverage is $(\\kappa^{\\lambda 2}+\\ell_{2011}^2)^{1/2}$ (Proposition~\\ref{prop:easc}).\\end{minipage}\n\\end{table}\n')

# ------------------------------------------------------------------ Table: main estimates and inference
def rowfmt(vals):
    return ' & '.join(vals) + '\\\\\n'
with open(f'{OUT}/tables/tab_main.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Output effect of the 2012 sanctions: point estimates and inference}\\label{tab:main}\n')
    f.write('\\begin{tabular}{@{}lccccccc@{}}\\toprule\n & & \\multicolumn{3}{c}{Normalisers (19 donors)} & \\multicolumn{3}{c}{Exposure-feasible (21 donors)}\\\\\n')
    f.write('\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}\n & EI & 2012--15 & 2016--17 & 2018--24 & 2012--15 & 2016--17 & 2018--24\\\\\\midrule\n')
    f.write('\\multicolumn{8}{@{}l}{\\emph{A. Point estimates (log points)}}\\\\\n')
    def ph3(g):
        return [num(float(np.mean(g[m]))) for m in PHM.values()]
    f.write(rowfmt(['\\quad SC', f"{b['ei_sc']:.1f}"] + ph3(b['g_sc']) + ph3(e['g_sc'])))
    f.write(rowfmt(['\\quad EBSC-min', f"{b['ei_min']:.1f} / {abs(e['ei_min']):.1f}"] + (['\\multicolumn{3}{c}{\\emph{no adequate fit (RMSPE ' + f"{b['rmspe_min']:.3f}" + ')}}'] if b['rmspe_min'] > 0.1 else ph3(b['g_ebsc_min'])) + ph3(e['g_ebsc_min'])))
    f.write(rowfmt(['\\quad EASC', f"{b['ei_sc']:.1f}"] + ph3(b['g_easc']) + ph3(e['g_easc'])))
    f.write(rowfmt(['\\quad EASC$^*$', f"{b['ei_tuned']:.1f} / {e['ei_tuned']:.1f}"] + ph3(b['g_easc_tuned']) + ph3(e['g_easc_tuned'])))
    f.write(rowfmt(['\\quad Pre-treatment RMSPE: SC; EBSC-min', ''] + ['\\multicolumn{3}{c}{' + f"{b['rmspe_sc']:.4f}; {b['rmspe_min']:.4f}" + '}'] + ['\\multicolumn{3}{c}{' + f"{e['rmspe_sc']:.4f}; {e['rmspe_min']:.4f}" + '}']))
    for est in ['SC', 'EASC']:
        f.write(f'\\multicolumn{{8}}{{@{{}}l}}{{\\emph{{{"B" if est == "SC" else "C"}. Inference for {est}}}}}\\\\\n')
        def get(T_, p, c):
            return T_[(T_.est == est) & (T_.phase == p)].iloc[0][c]
        f.write(rowfmt(['\\quad Placebo $p$-value', ''] + [f"{get(Tb, p, 'pval'):.3f}" for p in ph] + [f"{get(Te, p, 'pval'):.3f}" for p in ph]))
        f.write(rowfmt(['\\quad Noise s.d. $\\hat\\sigma$', ''] + [f"{get(Tb, p, 'sd'):.3f}" for p in ph] + [f"{get(Te, p, 'sd'):.3f}" for p in ph]))
        f.write(rowfmt(['\\quad Leverage $\\kappa$', ''] + [f"{get(Tb, p, 'kbar'):.1f}" for p in ph] + [f"{get(Te, p, 'kbar'):.1f}" for p in ph]))
        f.write(rowfmt(['\\quad 95\\% CI, $M=0$', ''] + [ci(get(Tb, p, 'ci0')) for p in ph] + [ci(get(Te, p, 'ci0')) for p in ph]))
        f.write(rowfmt(['\\quad 95\\% CI, $M=0.5$', ''] + [ci(get(Tb, p, 'ci05')) for p in ph] + [ci(get(Te, p, 'ci05')) for p in ph]))
        f.write(rowfmt(['\\quad Breakdown $M^*$', ''] + [f"{get(Tb, p, 'Mstar'):.2f}" for p in ph] + [f"{get(Te, p, 'Mstar'):.2f}" for p in ph]))
        f.write(rowfmt(['\\quad Breakdown $M^*$, robust $\\hat\\sigma$', ''] + [f"{get(Tb, p, 'Mstar_mad'):.2f}" for p in ph] + [f"{get(Te, p, 'Mstar_mad'):.2f}" for p in ph]))
        if est == 'EASC':
            f.write(rowfmt(['\\quad $100\\times\\bar\\phi$ (jackknife $t$)', ''] + [f"{100 * PHI['base'][p][0]:.2f} ({PHI['base'][p][0] / PHI['base'][p][1]:.1f})".replace('-', '$-$') for p in ph] + [f"{100 * PHI['ext'][p][0]:.2f} ({PHI['ext'][p][0] / PHI['ext'][p][1]:.1f})".replace('-', '$-$') for p in ph]))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.97\\textwidth}\\footnotesize\\emph{Notes.} Entries are averages of annual gaps in log GDP per capita over each phase. '
            'EBSC-min: simplex weights with the smallest attainable exposure imbalance; EASC: SC weights plus the regression correction $\\hat\\phi_t\\,\\text{EI}(\\hat w)$; EASC$^*$: frontier point minimising the estimated post-treatment MSE, then augmented. '
            'Placebo $p$-value: share of the $J+1$ units whose $|\\bar\\tau|/\\text{RMSPE}$ is at least Iran\'s. $\\hat\\sigma$: dispersion of placebo phase averages standardised by each placebo\'s pre-treatment RMSPE and rescaled to Iran\'s; for EASC it adds $|\\text{EI}|\\,\\overline{\\text{se}}(\\hat\\phi)$ in quadrature. The exposure regression controls for each donor\'s growth within each third of 1996--2010. '
            'CIs are bias-aware (Proposition~\\ref{prop:ci}) with bias bound $M\\kappa\\,\\text{RMSPE}$; $M^*$ is the largest $M$ for which the CI excludes zero. Robust $\\hat\\sigma$ replaces the standard deviation by $1.4826\\times$MAD. $\\bar\\phi$: phase average of the cross-donor exposure effect, log points per percentage point of oil rents, with delete-one-donor jackknife $t$-statistic.\\end{minipage}\n\\end{table}\n')

# ------------------------------------------------------------------ Table: estimators
with open(f'{OUT}/tables/tab_estimators.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Exposure imbalance of standard estimators and their exposure-augmented versions}\\label{tab:estimators}\n')
    f.write('\\begin{tabular}{@{}lccccccc@{}}\\toprule\n & & \\multicolumn{3}{c}{As published} & \\multicolumn{3}{c}{Exposure-augmented}\\\\\n\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}\n')
    f.write('Estimator & EI($\\hat w$) & 2012--15 & 2016--17 & 2018--24 & 2012--15 & 2016--17 & 2018--24\\\\\\midrule\n')
    for est in order:
        r_ = EI.loc[est]
        f.write(rowfmt([lab[est], '--' if np.isnan(r_.ei) else f'{r_.ei:.1f}'] + [num(r_[f'g_{p}']) for p in ph] + [num(r_[f'ea_{p}']) for p in ph]))
        if est == 'sc':
            A = json.load(open('../results/app_adh.json'))['ext']
            f.write(rowfmt(['SC with covariates, oil rents a predictor', f"{A['ei']:.1f}"] + [num(A['g'][p]) for p in ph] + [num(A['ge'][p]) for p in ph]))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.95\\textwidth}\\footnotesize\\emph{Notes.} Exposure-feasible pool (21 donors); the correction $\\hat\\phi_t$ is the same for every estimator. '
            'EI is defined for estimators that produce donor weights summing to one (augmented SC weights may be negative). SC with covariates: nested-$V$ synthetic control with predictors oil rents, outcome means over 1996--2000, 2001--05 and 2006--11, and the 2011 outcome; the selected $V$ gives oil rents a weight below $10^{-11}$. Matrix completion, generalized and robust SC produce no weights; their counterfactuals extrapolate Iran\'s loadings (Section~\\ref{sec:app-estimators}). '
            'Tuning parameters are chosen by forecasting Iran over 2008--11 from 1996--2007.\\end{minipage}\n\\end{table}\n')

# ------------------------------------------------------------------ Table: robustness
rob = R['rob']
with open(f'{OUT}/tables/tab_robust.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Robustness of the exposure-augmented estimates}\\label{tab:robust}\n')
    f.write('\\begin{tabular}{@{}lccccccc@{}}\\toprule\n & & \\multicolumn{3}{c}{EASC} & \\multicolumn{3}{c}{EBSC-min}\\\\\n\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}\n')
    f.write('Specification & EI(SC) & 2012--15 & 2016--17 & 2018--24 & 2012--15 & 2016--17 & 2018--24\\\\\\midrule\n')
    for _, r_ in rob[~rob.spec.str.contains('latent factor')].iterrows():
        ebm = [num(r_[f'ebmin_{p}']) for p in ph] if r_.rmspe_min < 0.1 else ['\\emph{infeasible}', '', '']
        f.write(rowfmt([r_.spec.replace('1996-2011', '1996--2011').replace('2002-2011', '2002--2011'), f'{r_.ei_sc:.1f}'] + [num(r_[f'easc_{p}']) for p in ph] + ebm))
    f.write('\\midrule\n' + rowfmt(['SC (all specifications)', ''] + [num(rob.iloc[0][f'sc_{p}']) for p in ph] + ['', '', '']))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.97\\textwidth}\\footnotesize\\emph{Notes.} Rows 1--4 use the 19 normalisers; rows 5--10 add Azerbaijan and Angola (row 7 adds Angola only, row 8 Azerbaijan only). '
            'The V-Dem measure is petroleum, coal and gas income per capita relative to GDP per capita \\citep{haber2011}, 1996--2006 mean; its scale differs from oil rents, so EI is not comparable across measures. '
            'EBSC-min is reported as infeasible when the minimum attainable imbalance forces a pre-treatment RMSPE above 0.1. SC estimates do not depend on the exposure measure or on the latent factors.\\end{minipage}\n\\end{table}\n')

# ------------------------------------------------------------------ Appendix tables: in-time placebos, backdating, leave-one-out
it = RB['intime']
with open(f'{OUT}/tables/tabA_intime.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{In-time placebos around the 2008--09 oil collapse (sample 1996--2011)}\\label{tab:intime}\n')
    f.write('\\begin{tabular}{@{}llcccccccc@{}}\\toprule\n & Placebo & & & & \\multicolumn{2}{c}{Mean gap, placebo period} & \\multicolumn{2}{c}{Mean $|$gap$|$}\\\\\n\\cmidrule(lr){6-7}\\cmidrule(lr){8-9}\n')
    f.write('Pool & treated year & EI & RMSPE & $\\max|\\ell_t|$ & SC & EASC & SC & EASC\\\\\\midrule\n')
    for _, r_ in it.iterrows():
        f.write(rowfmt(['Normalisers' if r_.pool == 'base' else 'Exposure-feasible', str(r_.t0), f'{r_.ei:.1f}', f'{r_.rmspe:.3f}', f'{r_.plmax:.1f}',
                        num(r_.sc_post), num(r_.easc_post), num(r_.sc_abs, sign=False), num(r_.easc_abs, sign=False)]))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.95\\textwidth}\\footnotesize\\emph{Notes.} Data end in 2011. Exposure is the mean of oil rents up to the year before the placebo date; the base year of $\\hat\\phi_t$ is the last placebo pre-treatment year. '
            'No treatment occurs in the placebo window in the paper\'s design; earlier UN and US measures (2006--10) are part of the pre-treatment period by assumption, so non-zero placebo gaps reflect estimator error or effects of those measures.\\end{minipage}\n\\end{table}\n')
bd = RB['backdate']
with open(f'{OUT}/tables/tabA_backdate.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Backdating the treatment}\\label{tab:backdate}\n')
    f.write('\\begin{tabular}{@{}llccccccc@{}}\\toprule\n & & \\multicolumn{3}{c}{SC} & \\multicolumn{3}{c}{EASC} & EASC\\\\\n\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}\n')
    f.write('Pool & First treated year & 2012--15 & 2016--17 & 2018--24 & 2012--15 & 2016--17 & 2018--24 & to 2011\\\\\\midrule\n')
    for _, r_ in bd.iterrows():
        f.write(rowfmt(['Normalisers' if r_.pool == 'base' else 'Exposure-feasible', str(r_.t0)] + [num(r_[f'sc_{p}']) for p in ph] + [num(r_[f'easc_{p}']) for p in ph] + [num(r_.easc_pre12)]))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.95\\textwidth}\\footnotesize\\emph{Notes.} The first treated year is moved earlier; weights, exposure (mean up to the year before) and $\\hat\\phi_t$ (base year: the year before) are re-estimated. '
            'The last column is the mean EASC gap between the backdated first treated year and 2011, before the actual treatment.\\end{minipage}\n\\end{table}\n')
lo = RB['loo']
with open(f'{OUT}/tables/tabA_loo.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Leave one donor out}\\label{tab:loo}\n')
    f.write('\\begin{tabular}{@{}llcccccccc@{}}\\toprule\n & & & & \\multicolumn{3}{c}{SC} & \\multicolumn{3}{c}{EASC}\\\\\n\\cmidrule(lr){5-7}\\cmidrule(lr){8-10}\n')
    f.write('Pool & Dropped & Weight & EI & 2012--15 & 2016--17 & 2018--24 & 2012--15 & 2016--17 & 2018--24\\\\\\midrule\n')
    for _, r_ in lo.iterrows():
        f.write(rowfmt(['Normalisers' if r_.pool == 'base' else 'Exposure-feasible', NAMES[r_.dropped], f'{r_.weight:.3f}', f'{r_.ei:.1f}'] + [num(r_[f'sc_{p}']) for p in ph] + [num(r_[f'easc_{p}']) for p in ph]))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.95\\textwidth}\\footnotesize\\emph{Notes.} Each row drops one donor with SC weight above 0.01 and re-estimates weights and $\\hat\\phi_t$.\\end{minipage}\n\\end{table}\n')

# ------------------------------------------------------------------ Appendix table: weights and exposure
with open(f'{OUT}/tables/tabA_weights.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Donors: oil exposure and weights}\\label{tab:weights}\n')
    f.write('\\begin{tabular}{@{}lcccc@{}}\\toprule\nDonor & Oil rents, \\% GDP & SC weight & EBSC-min weight & EBSC-min weight\\\\\n & 1996--2011 & & (normalisers) & (exposure-feasible)\\\\\\midrule\n')
    wmb = pd.Series(b['path'][0]['w'], index=BASE); wme = pd.Series(e['path'][0]['w'], index=EXT); wsc = pd.Series(b['w_sc'], index=BASE)
    for j in sorted(EXT, key=lambda j: -S_RENTS[j]):
        f.write(rowfmt([NAMES[j], f'{S_RENTS[j]:.2f}', f'{wsc.get(j, 0):.3f}' if j in BASE else '--', f'{wmb.get(j, 0):.3f}' if j in BASE else '--', f'{wme[j]:.3f}']))
    f.write('\\midrule\n' + rowfmt(['Iran', f"{S_RENTS['IRN']:.2f}", '', '', '']))
    f.write(rowfmt(['Weighted donor exposure', '', f"{S_RENTS[BASE].values @ b['w_sc']:.2f}", f"{S_RENTS[BASE].values @ b['path'][0]['w']:.2f}", f"{S_RENTS[EXT].values @ e['path'][0]['w']:.2f}"]))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.8\\textwidth}\\footnotesize\\emph{Notes.} Oil rents: WDI NY.GDP.PETR.RT.ZS; the Dominican Republic and Panama report no oil rents and are set to zero. '
            'SC weights are identical in the two pools because Azerbaijan and Angola receive zero weight.\\end{minipage}\n\\end{table}\n')


# ------------------------------------------------------------------ Appendix table: estimators, normaliser pool
EIb = R['EI']['base']
with open(f'{OUT}/tables/tabA_estimators_base.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Standard estimators before and after exposure augmentation, normaliser pool}\\label{tab:estimators-base}\n')
    f.write('\\begin{tabular}{@{}lccccccc@{}}\\toprule\n & & \\multicolumn{3}{c}{As published} & \\multicolumn{3}{c}{Exposure-augmented}\\\\\n\\cmidrule(lr){3-5}\\cmidrule(lr){6-8}\n')
    f.write('Estimator & EI($\\hat w$) & 2012--15 & 2016--17 & 2018--24 & 2012--15 & 2016--17 & 2018--24\\\\\\midrule\n')
    for est in order:
        r_ = EIb.loc[est]
        f.write(rowfmt([lab[est], '--' if np.isnan(r_.ei) else f'{r_.ei:.1f}'] + [num(r_[f'g_{p}']) for p in ph] + [num(r_[f'ea_{p}']) for p in ph]))
        if est == 'sc':
            A = json.load(open('../results/app_adh.json'))['base']
            f.write(rowfmt(['SC with covariates, oil rents a predictor', f"{A['ei']:.1f}"] + [num(A['g'][p]) for p in ph] + [num(A['ge'][p]) for p in ph]))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.95\\textwidth}\\footnotesize\\emph{Notes.} As Table~\\ref{tab:estimators}, with the 19 normalisers as donors and $\\hat\\phi_t$ estimated on the same 19 donors, so that the correction extrapolates beyond the donors\' exposure range.\\end{minipage}\n\\end{table}\n')

json.dump(dict(LEV=LEV, s_syn=s_syn), open('../results/app_numbers.json', 'w'), indent=1, default=float)
print('done')
# ------------------------------------------------------------------ Figure: influence of donors on the exposure regression
INF = json.load(open('../results/app_influence.json'))
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
for i, (key, lab_) in enumerate([('base', 'Normalisers (19)'), ('ext', 'Exposure-feasible (21)')]):
    a = ax[i]; d = pd.DataFrame(INF[key]['rows']).sort_values('phi_siege')
    cols = [C['ebsc'] if x in ('AZE', 'AGO') else C['easc'] for x in d.donor]
    a.barh(range(len(d)), d.phi_siege, color=cols, height=0.7)
    a.axvline(INF[key]['full']['siege'], color='black', lw=0.9, ls='--')
    a.set_yticks(range(len(d))); a.set_yticklabels([f"{NAMES[x]} ({h:.2f})" for x, h in zip(d.donor, d.hat)], fontsize=6.5)
    a.set_title(f'({"ab"[i]}) {lab_}'); a.set_xlabel(r'$100\times\bar\phi_{2018-24}$ with donor deleted')
fig.tight_layout(); fig.savefig(f'{OUT}/figures/figA_influence.pdf'); plt.close(fig)

# ------------------------------------------------------------------ Appendix table: leverage and breakdown by number of factors
from ebsc import breakdown_M
with open(f'{OUT}/tables/tabA_factors.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Leverage and breakdown values by number of latent factors}\\label{tab:factors-k}\n')
    f.write('\\begin{tabular}{@{}llccccc@{}}\\toprule\nPool & $k$ & $R^2$ & $\\kappa$ 2012--15 & $\\kappa$ 2016--17 & $\\kappa$ 2018--24 & $M^*$ (SC, 2012--15)\\\\\\midrule\n')
    for key, lab_ in [('base', 'Normalisers'), ('ext', 'Exposure-feasible')]:
        T_ = I[key]['table']; r_ = T_[(T_.est == 'SC') & (T_.phase == 'shock')].iloc[0]
        for k in (1, 2, 3):
            L = INF['leverage_k'][f'{key}_k{k}']
            f.write(rowfmt([lab_ if k == 1 else '', str(k), f"{L['r2']:.3f}", f"{L['shock']:.1f}", f"{L['relief']:.1f}", f"{L['siege']:.1f}", f"{breakdown_M(r_.tau, L['shock'], r_.rmspe, r_.sd):.2f}"]))
    f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.9\\textwidth}\\footnotesize\\emph{Notes.} $k$ principal components of two-way demeaned, exposure-orthogonalised donor outcomes; the paper uses $k=2$. $\\kappa$ is the synthetic-control leverage of the phase average; $M^*$ is the breakdown value of the 2012--15 synthetic-control estimate.\\end{minipage}\n\\end{table}\n')

from texutil import wrap_tables
wrap_tables()
