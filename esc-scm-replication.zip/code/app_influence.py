"""Influence diagnostics for the exposure regression: hat values and delete-one-donor phase averages of phi."""
import numpy as np, pandas as pd, json
from app import wide, BASE, EXT, YEARS, PRE, PH, S_RENTS, X
from ebsc import exposure_effects_phase, donor_factors, partial_leverage, leverage_sc
out = {}
for key, pool in [('base', BASE), ('ext', EXT)]:
    Y = wide(pool); Y0 = Y[pool].values; s0 = S_RENTS[pool].values; J = len(pool)
    pre_idx = np.where(PRE)[0]; b = list(YEARS).index(2011); pre_idx = pre_idx[pre_idx < b]
    C = np.column_stack([Y0[th[-1]] - Y0[th[0]] for th in np.array_split(pre_idx, 3)])
    Xr = np.column_stack([np.ones(J), s0, C]); H = np.diag(Xr @ np.linalg.pinv(Xr.T @ Xr) @ Xr.T)
    masks = {p: (YEARS >= a) & (YEARS <= c) for p, (a, c) in PH.items()}
    full = exposure_effects_phase(Y0, s0, PRE, b, masks)
    rows = []
    for j, d in enumerate(pool):
        keep = [i for i in range(J) if i != j]
        r = exposure_effects_phase(Y0[:, keep], s0[keep], PRE, b, masks)
        rows.append(dict(donor=d, s=float(s0[j]), hat=float(H[j]), **{f'phi_{p}': 100 * r[p][0] for p in PH}))
    out[key] = dict(hat_mean=float(H.mean()), full={p: 100 * v[0] for p, v in full.items()}, rows=rows)
    df = pd.DataFrame(rows).sort_values('hat', ascending=False)
    print(key, 'full phi x100:', {p: round(100 * v[0], 2) for p, v in full.items()}); print(df.round(3).head(6).to_string())
# leverage with k = 1, 2, 3 latent factors
lev = {}
for key, pool in [('base', BASE), ('ext', EXT)]:
    Y = wide(pool); Y0 = Y[pool].values; s0 = S_RENTS[pool].values
    for k in (1, 2, 3):
        Fl, _ = donor_factors(Y0, k=k, s=s0)
        lev[f'{key}_k{k}'] = {p: leverage_sc(X, Fl, PRE, (YEARS >= a) & (YEARS <= c)) for p, (a, c) in PH.items()}
        lev[f'{key}_k{k}']['r2'] = partial_leverage(X, Fl, PRE)[1]
print(pd.DataFrame(lev).round(2).T.to_string())
out['leverage_k'] = lev
json.dump(out, open('../results/app_influence.json', 'w'), indent=1)
