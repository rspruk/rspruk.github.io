"""LaTeX tables and figures for the Monte Carlo (Section 5 and Online Appendix)."""
import numpy as np, pandas as pd, pickle, sys, os, json
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
tag = sys.argv[1] if len(sys.argv) > 1 else 'mc_final'
sys.argv = [sys.argv[0], tag]
from mc_summary import B, C, D, res as RES
from mc import SCEN, EST, PH, XR, F1, PRE, YEARS, GAMMA, BSLOPE, BASEIDX
OUT = '../paper'
plt.rcParams.update({'font.family': 'serif', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.titlesize': 9.5, 'legend.fontsize': 8, 'legend.frameon': False})
SC_ = [s for s in SCEN if s in set(B.scn)]
SC_MAIN = [s for s in SC_ if s in ('S0', 'S1', 'S2', 'S3', 'S4', 'S5', 'S6', 'S7')]
SC_X = [s for s in SC_ if s in ('S3', 'S8', 'S9', 'S10', 'S11')]
SHORT = {'S0': 'No exposure', 'S1': 'In-span shock', 'S2': 'Outside hull', 'S3': 'Inside hull', 'S4': 'Noisy exposure',
         'S5': 'Concave, outside', 'S6': 'Concave, inside', 'S7': '38 donors', 'S8': 'Loadings $\\sim$ exposure', 'S9': 'Latent break', 'S10': 'S8+S9, treated out', 'S11': 'Hidden shock'}
PHL = {'shock': '2012--15', 'relief': '2016--17', 'siege': '2018--24'}
LAB = {'SC': 'SC', 'ASCM': 'Augmented SC', 'SDID': 'Synthetic DiD', 'DSC': 'De-meaned SC', 'GSC': 'Generalized SC',
       'MC': 'Matrix completion', 'EBSC-min': 'EBSC-min', 'EASC': 'EASC', 'EASC*': 'EASC$^*$'}


def num(v, d=3):
    s = f'{abs(v):.{d}f}'
    return f'$-${s}' if v < -0.5 * 10 ** (-d) else s


def bias_table(phases, fname, caption, label, SC_=None, note=None):
    SC_ = SC_ or SC_MAIN
    with open(f'{OUT}/tables/{fname}', 'w') as f:
        f.write(f'\\begin{{table}}[htbp]\\centering\\small\n\\caption{{{caption}}}\\label{{{label}}}\n')
        f.write('\\setlength{\\tabcolsep}{4pt}\\begin{tabular}{@{}l' + 'c' * len(SC_) + '@{}}\\toprule\n')
        f.write(' & ' + ' & '.join(f'{s}' for s in SC_) + '\\\\\n')
        f.write(' & ' + ' & '.join(f'\\scriptsize {SHORT[s]}' for s in SC_) + '\\\\\\midrule\n')
        for p in phases:
            for stat, nm in [('bias', 'Bias'), ('rmse', 'RMSE')]:
                f.write(f'\\multicolumn{{{len(SC_) + 1}}}{{@{{}}l}}{{\\emph{{{nm}, {PHL[p]} average}}}}\\\\\n')
                tb = B[B.phase == p].pivot(index='est', columns='scn', values=stat).reindex(EST)
                for e in EST:
                    vals = [num(tb.loc[e, s]) for s in SC_]
                    if stat == 'rmse':
                        best = tb[SC_].min(axis=0)
                        vals = [f'\\textbf{{{v}}}' if abs(tb.loc[e, s] - best[s]) < 1e-12 else v for v, s in zip(vals, SC_)]
                    f.write(f'\\quad {LAB[e]} & ' + ' & '.join(vals) + '\\\\\n')
        kb = {sc: float(np.mean([r['inf'][('SC', 'siege', 'kbar')] for r in RES if r['scn'] == sc])) for sc in SC_}
        if note is not None:
            f.write('\\midrule\n\\quad Mean $\\kappa$ (SC), 2018--24 & ' + ' & '.join(f'{kb[sc]:.1f}' for sc in SC_) + '\\\\\n\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.97\\textwidth}\\footnotesize\\emph{Notes.} ' + note + '\\end{minipage}\n\\end{table}\n'); return
        f.write('\\midrule\n\\quad Mean $\\kappa$ (SC), 2018--24 & ' + ' & '.join(f'{kb[sc]:.1f}' for sc in SC_) + '\\\\\n')
        f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.97\\textwidth}\\footnotesize\\emph{Notes.} '
                '500 replications per design. Errors are phase averages of $\\hat\\tau_t-\\tau_t$; the true effect is $-0.10$ in 2012--15 and $-0.05$ afterwards. '
                'Bold: smallest RMSE in the column. Designs: S0 no exposure channel ($\\gamma=0$); S1 post-2012 oil price on its pre-2012 relation with the latent trend; '
                'S2 actual Brent, treated exposure 22.87 against donor exposures of the 19 normalisers (maximum 16.56); S3 as S2 with 21 donors (adds 26.52 and 38.42); '
                'S4 as S2 with exposure observed with multiplicative log-normal error (s.d.\\ 0.3); S5 as S2 with concave exposure $\\theta_j=\\gamma c(1-e^{-s_j/c})$, $c=20$; '
                'S6 as S5 with 21 donors; S7 as S2 with 38 donors; S8--S11 are the adverse designs of Section~\\ref{sec:mc-design}.\\end{minipage}\n\\end{table}\n')


bias_table(['siege'], 'tab_mc_bias.tex', 'Monte Carlo: bias and RMSE of the 2018--24 average effect', 'tab:mc-bias')
bias_table(['shock', 'relief'], 'tabA_mc_bias.tex', 'Monte Carlo: bias and RMSE, 2012--15 and 2016--17', 'tab:mc-bias-app')



def cover_table(phases, fname, caption, label, ests=('SC', 'EASC'), SC_=None):
    SC_ = SC_ or SC_MAIN
    with open(f'{OUT}/tables/{fname}', 'w') as f:
        f.write(f'\\begin{{table}}[htbp]\\centering\\small\n\\caption{{{caption}}}\\label{{{label}}}\n')
        f.write('\\setlength{\\tabcolsep}{4pt}\\begin{tabular}{@{}ll' + 'c' * len(SC_) + '@{}}\\toprule\n')
        f.write(' & & ' + ' & '.join(SC_) + '\\\\\\midrule\n')
        for p in phases:
            for stat, nm in [('cover', 'Coverage of 95\\% bias-aware intervals'), ('len', 'Average length')]:
                f.write(f'\\multicolumn{{{len(SC_) + 2}}}{{@{{}}l}}{{\\emph{{{nm}, {PHL[p]}}}}}\\\\\n')
                for e in ests:
                    for M in (0.0, 0.5, 1.0):
                        sub = C[(C.phase == p) & (C.est == e) & (C.M == M)].set_index('scn')[stat]
                        vals = [f'{sub[s]:.3f}' if stat == 'len' else f'{sub[s]:.2f}' for s in SC_]
                        f.write(f'\\quad {e.replace("mad", "") if M == 0 else ""} & $M={M:g}$ & ' + ' & '.join(vals) + '\\\\\n')
        f.write('\\bottomrule\\end{tabular}\n\\par\\smallskip\\begin{minipage}{0.92\\textwidth}\\footnotesize\\emph{Notes.} Intervals of Proposition~\\ref{prop:ci} with bias bound $M\\hat\\kappa\\,\\RMSPE$ and noise s.d.\\ from standardised in-space placebos (Section~\\ref{sec:inference}); '
                'for EASC the jackknife variance of the correction is added. Nominal coverage 0.95. Designs as in Table~\\ref{tab:mc-bias}.\\end{minipage}\n\\end{table}\n')


cover_table(['relief', 'siege'], 'tab_mc_cover.tex', 'Monte Carlo: coverage and length of bias-aware confidence intervals', 'tab:mc-cover')
cover_table(['shock'], 'tabA_mc_cover.tex', 'Monte Carlo: coverage and length, 2012--15', 'tab:mc-cover-app')
if len(SC_X) == 5:
    bias_table(['shock', 'siege'], 'tab_mc_adverse.tex', 'Monte Carlo: adverse designs that stress the exposure correction', 'tab:mc-adverse', SC_=SC_X, note='500 replications per design; true effects $-0.10$ (2012--15) and $-0.05$ (2018--24). S3 is the common baseline (21 donors, treated unit inside the exposure hull). S8: composite trend loadings correlated with exposure, $\\xi_j=N(0,0.08^2)+0.004(s_j-\\bar s)$. S9: innovation s.d.\\ of the latent random walk rises from 0.03 to 0.30 after 2014. S10: S8 and S9 with the treated unit\'s trend loading two s.d.\\ above the donor mean. S11: a second, unobserved shock, zero before 2015 and $-1$ by 2024, with donor loadings $0.004s_j+N(0,0.03^2)$ and a treated loading 0.06 above that. Bold: smallest RMSE in the column.')
    cover_table(['siege'], 'tabA_mc_cover_adverse.tex', 'Monte Carlo: coverage and length in the adverse designs, 2018--24', 'tab:mc-cover-adverse', SC_=SC_X)
cover_table(['relief', 'siege'], 'tabA_mc_cover_mad.tex', 'Monte Carlo: coverage with the robust (MAD) noise scale', 'tab:mc-cover-mad', ests=('SCmad', 'EASCmad'))

# diagnostics table
dg = D.xs('mean', axis=1, level=1)
with open(f'{OUT}/tables/tabA_mc_diag.tex', 'w') as f:
    f.write('\\begin{table}[htbp]\\centering\\small\n\\caption{Monte Carlo: diagnostics and selected frontier points (means over replications)}\\label{tab:mc-diag}\n')
    f.write('\\setlength{\\tabcolsep}{4pt}\\begin{tabular}{@{}l' + 'c' * len(SC_) + '@{}}\\toprule\n & ' + ' & '.join(SC_) + '\\\\\\midrule\n')
    for k, nm, d in [('r2', 'Pre-treatment $R^2$ of $x_t$ on $\\hat\\lambda_t$', 3), ('plmax', '$\\max_{t>T_0}|\\hat\\ell_t|$', 2), ('dmin', '$d_{\\min}$', 2),
                     ('ei_sc', 'EI of SC', 2), ('ei_star', 'EI of EASC$^*$', 2), ('frac', 'EASC$^*$: frontier position (1 = SC)', 2),
                     ('rmspe', 'RMSPE of SC', 4), ('rmspe_min', 'RMSPE of EBSC-min', 4)]:
        f.write(f'{nm} & ' + ' & '.join(f'{dg.loc[s, k]:.{d}f}' for s in SC_) + '\\\\\n')
    f.write('\\bottomrule\\end{tabular}\n\\end{table}\n')

# figure: RMSE by design, later phases
sel = ['SC', 'ASCM', 'SDID', 'GSC', 'MC', 'EBSC-min', 'EASC']
mk = dict(SC='o', ASCM='s', SDID='^', GSC='v', MC='P', **{'EBSC-min': 'X'}, EASC='D')
col = dict(SC='0.15', ASCM='0.45', SDID='0.6', GSC='0.35', MC='0.7', **{'EBSC-min': '#d9822b'}, EASC='#1f4e9c')
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.3), sharey=True)
for i, p in enumerate(['relief', 'siege']):
    a = ax[i]; tb = B[B.phase == p].pivot(index='est', columns='scn', values='rmse')
    for k, e in enumerate(sel):
        xs = np.arange(len(SC_MAIN)) + (k - 3) * 0.09
        a.scatter(xs, [min(tb.loc[e, s], 0.25) for s in SC_MAIN], marker=mk[e], color=col[e], s=22 if e != 'EASC' else 30, label=LAB[e].replace('$^*$', '*'), zorder=3)
    a.set_xticks(range(len(SC_MAIN))); a.set_xticklabels(SC_MAIN); a.set_title(['(a) 2016–17', '(b) 2018–24'][i]); a.axhline(0, color='0.7', lw=0.5)
    a.set_ylim(0, 0.26); a.text(len(SC_MAIN) - 0.5, 0.252, 'values capped at 0.25', fontsize=7, ha='right', color='0.4')
ax[0].set_ylabel('RMSE of the phase average')
h, l = ax[0].get_legend_handles_labels(); fig.legend(h, l, loc='lower center', ncol=7, fontsize=7.5, columnspacing=0.9, handletextpad=0.2)
fig.tight_layout(rect=(0, 0.07, 1, 1)); fig.savefig(f'{OUT}/figures/fig9_mc_rmse.pdf'); plt.close(fig)

# figure: coverage vs M
fig, ax = plt.subplots(1, 2, figsize=(7.4, 2.8), sharey=True)
for i, e in enumerate(['SC', 'EASC']):
    a = ax[i]
    for s, c_ in zip(SC_MAIN, plt.cm.viridis(np.linspace(0, 0.9, len(SC_MAIN)))):
        sub = C[(C.phase == 'siege') & (C.est == e) & (C.M != 'rank') & (C.scn == s)].sort_values('M')
        a.plot(sub.M.astype(float), sub.cover, marker='o', ms=3, color=c_, label=f'{s}: {SHORT[s]}')
    a.axhline(0.95, color='0.3', lw=0.6, ls='--'); a.set_xlabel('M'); a.set_title(f'({"ab"[i]}) {e}, 2018–24'); a.set_xticks([0, 0.5, 1])
ax[0].set_ylabel('Coverage'); ax[1].legend(loc='lower right', fontsize=6.5, ncol=2)
fig.tight_layout(); fig.savefig(f'{OUT}/figures/fig10_mc_coverage.pdf'); plt.close(fig)

# calibration numbers
Xd = np.column_stack([np.ones(len(YEARS)), F1]); bcoef = np.linalg.lstsq(Xd[PRE], XR[PRE], rcond=None)[0]; r = XR - Xd @ bcoef
ph = {k: (YEARS >= a) & (YEARS <= b) for k, (a, b) in PH.items()}
cal = dict(r2=float(1 - np.var(r[PRE]) / np.var(XR[PRE])), slope=float(BSLOPE), gamma=GAMMA,
           phi_implied={k: float(GAMMA * np.mean(r[m] - r[BASEIDX])) for k, m in ph.items()},
           ell={k: float(np.mean(r[m]) / np.sqrt(np.mean(r[PRE] ** 2))) for k, m in ph.items()})
json.dump(cal, open('../results/mc_calibration.json', 'w'), indent=1)
print(cal)
from texutil import wrap_tables
wrap_tables()
