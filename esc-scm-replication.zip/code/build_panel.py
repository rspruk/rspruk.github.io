"""Build the 2012-design analysis panel.
Sources: user panel (data-input.xlsx, WDI Dec-2025 vintage), WDI API extracts (wdi/*.csv),
V-Dem v15+ (vdemdata GitHub), Penn World Table 10.01."""
import pandas as pd, numpy as np, pyreadr, glob, os
ROOT='../data/raw'
name2iso={'Bulgaria':'BGR','Egypt':'EGY','Indonesia':'IDN','Iran':'IRN','Jordan':'JOR','Malaysia':'MYS',
 'Morocco':'MAR','Romania':'ROU','Serbia':'SRB','South Africa':'ZAF','Tunisia':'TUN','Turkiye':'TUR','Vietnam':'VNM'}
p=pd.read_excel(f'{ROOT}/data-input.xlsx','Sheet1'); p['iso']=p.country.map(name2iso)
p=p[['iso','year','gdppc','inflation','trade']]
def load(pat,col):
    d=pd.concat([pd.read_csv(f) for f in glob.glob(f"{os.environ.get('WDI_DIR', ROOT + '/wdi')}/{pat}_*.csv")]); return d.rename(columns={col:col})
gdp=load('gdp','gdppc'); gdi=load('gdi','gdi'); inf=load('inf','inflation')
base=pd.MultiIndex.from_product([sorted(set(p.iso)|set(gdp.iso)|set(gdi.iso)),range(1990,2026)],names=['iso','year']).to_frame(index=False)
d=base.merge(p,on=['iso','year'],how='left')
# fill WDI gdppc / inflation for countries not in user panel
for src,col in [(gdp,'gdppc'),(inf,'inflation')]:
    d=d.merge(src.rename(columns={col:col+'_w'}),on=['iso','year'],how='left')
    d[col]=d[col].fillna(d[col+'_w']); d=d.drop(columns=col+'_w')
d=d.merge(gdi,on=['iso','year'],how='left')
# V-Dem
v=pd.read_csv(f'{ROOT}/vdem_sub.csv').rename(columns={'country_text_id':'iso'})
keep=['iso','year','v2x_rule','v2x_corr','v2xcl_prpty','v2x_jucon','v2x_neopat','v2x_libdem','v2x_execorr',
      'e_wbgi_pve','e_wbgi_cce','e_wbgi_rle','e_wbgi_gee','e_gdppc','e_total_oil_income_pc']
d=d.merge(v[keep],on=['iso','year'],how='left')
m=pd.read_csv(f'{ROOT}/vdem_mech.csv').rename(columns={'country_text_id':'iso'})
d=d.merge(m[['iso','year','v2x_ex_military','v2xnp_regcorr','v2exrescon','v2exembez','v2jucorrdc','v2regsupgroupssize']],on=['iso','year'],how='left')
d['oil_share']=d.e_total_oil_income_pc/(d.e_gdppc*1000)*100
# PWT
r=pyreadr.read_r(f'{ROOT}/pwt10.01.rda'); w=r[list(r.keys())[0]].rename(columns={'isocode':'iso'})
w=w[['iso','year','hc','csh_x','csh_m','csh_i','pop']]; w['year']=w.year.astype(int)
w['open_pwt']=(w.csh_x-w.csh_m)*100   # csh_m is negative in PWT
d=d.merge(w[['iso','year','hc','open_pwt','pop']],on=['iso','year'],how='left')
d=d.sort_values(['iso','year'])
d['popg']=d.groupby('iso')['pop'].pct_change()*100
d['lgdppc']=np.log(d.gdppc)
d['linf']=np.log1p(d.inflation/100)*100   # log-inflation in "percent-equivalent" units
d=d[(d.year>=1996)&(d.year<=2025)]
d.to_csv('../data/panel_2012.csv',index=False)
cov=d[d.year.between(1996,2024)].groupby('iso')[['lgdppc','gdi','linf','v2x_rule','e_wbgi_pve','hc','open_pwt','oil_share']].count()
print(cov.to_string())
