"""Synthetic control engine (Abadie, Diamond & Hainmueller 2010) with nested V selection,
in-space placebos, leave-one-out, and Chernozhukov-Wuthrich-Zhu (2021) conformal tests."""
import numpy as np, pandas as pd
from scipy.optimize import nnls, minimize

YEARS = np.arange(1996, 2026)


def solve_w(X1, X0, v):
    """min (X1-X0 w)' diag(v) (X1-X0 w)  s.t. w>=0, sum w = 1  (augmented NNLS + SLSQP polish)."""
    s = np.sqrt(v)
    A = X0 * s[:, None]; b = X1 * s
    M = 1e3 * (np.abs(A).max() + 1.0)
    Aa = np.vstack([A, M * np.ones(A.shape[1])]); ba = np.append(b, M)
    w, _ = nnls(Aa, ba, maxiter=5000)
    w = np.clip(w, 0, None); w = w / w.sum()
    return w


def polish(X1, X0, v, w0):
    f = lambda w: np.sum(v * (X1 - X0 @ w) ** 2)
    r = minimize(f, w0, method='SLSQP', bounds=[(0, 1)] * len(w0),
                 constraints=[{'type': 'eq', 'fun': lambda w: w.sum() - 1}],
                 options={'ftol': 1e-14, 'maxiter': 500})
    w = np.clip(r.x, 0, None) if r.success else w0
    return w / w.sum()


def fit(X1, X0, Z1, Z0, n_starts=3, seed=0):
    """Nested optimisation: V chosen to minimise pre-period outcome MSPE (Z = pre-period outcomes)."""
    k = X1.shape[0]
    sd = X0.std(axis=1, ddof=0); sd[sd == 0] = 1.0
    X1n, X0n = X1 / sd, X0 / sd[:, None]
    def loss(lv):
        v = np.exp(lv - lv.max()); v = v / v.sum()
        w = solve_w(X1n, X0n, v)
        return np.mean((Z1 - Z0 @ w) ** 2)
    rng = np.random.default_rng(seed)
    starts = [np.zeros(k)]
    # regression-based start: |coef| of outcome pre-mean on predictors across all units
    try:
        Xa = np.column_stack([X1n, X0n]).T; ya = np.append(Z1.mean(), Z0.mean(axis=0))
        Xa1 = np.column_stack([np.ones(len(ya)), Xa])
        coef = np.linalg.lstsq(Xa1, ya, rcond=None)[0][1:]
        starts.append(np.log(coef ** 2 + 1e-6))
    except Exception:
        pass
    while len(starts) < n_starts:
        starts.append(rng.normal(0, 1.5, k))
    best = None
    for s0 in starts:
        r = minimize(loss, s0, method='Nelder-Mead', options={'maxiter': 3000, 'xatol': 1e-4, 'fatol': 1e-10})
        if best is None or r.fun < best.fun:
            best = r
    v = np.exp(best.x - best.x.max()); v = v / v.sum()
    w = solve_w(X1n, X0n, v)
    w = polish(X1n, X0n, v, w)
    return w, v


class Spec:
    """One outcome specification."""
    def __init__(self, panel, outcome, covars, t0, fit_years, end_year, lag_windows=None, last_lag=True):
        self.P, self.y, self.cov, self.t0 = panel, outcome, covars, t0
        self.fit_years = [t for t in fit_years if t < t0]
        self.end = end_year
        self.lag_windows = lag_windows
        self.last_lag = last_lag

    def matrices(self, units):
        P = self.P[self.P.iso.isin(units)]
        Y = P.pivot(index='year', columns='iso', values=self.y).reindex(columns=units)
        rows = []
        pre = [t for t in range(1996, self.t0)]
        for c in self.cov:
            M = P.pivot(index='year', columns='iso', values=c).reindex(columns=units)
            rows.append(M.loc[M.index.isin(pre)].mean(axis=0).values)
        wins = self.lag_windows or []
        for a, b in wins:
            yy = [t for t in self.fit_years if a <= t <= b]
            rows.append(Y.loc[yy].mean(axis=0).values)
        if self.last_lag:
            rows.append(Y.loc[max(self.fit_years)].values)
        X = np.array(rows, dtype=float)
        return X, Y

    def run(self, treated, donors, seed=0):
        units = [treated] + list(donors)
        X, Y = self.matrices(units)
        ok = ~np.isnan(X).any(axis=1)
        X = X[ok]
        Zy = Y.loc[self.fit_years].values
        X1, X0 = X[:, 0], X[:, 1:]
        Z1, Z0 = Zy[:, 0], Zy[:, 1:]
        w, v = fit(X1, X0, Z1, Z0, seed=seed)
        years = [t for t in Y.index if t <= self.end]
        Yt = Y.loc[years]
        synth = Yt.values[:, 1:] @ w
        gap = pd.Series(Yt.values[:, 0] - synth, index=years)
        pre_err = gap.loc[self.fit_years]
        post = gap.loc[[t for t in years if t >= self.t0]]
        post = post.dropna()
        pre_rmspe = max(float(np.sqrt(np.mean(pre_err ** 2))), 1e-6)
        post_rmspe = float(np.sqrt(np.mean(post ** 2)))
        return dict(w=pd.Series(w, index=donors), v=v, gap=gap, actual=Yt.iloc[:, 0],
                     synth=pd.Series(synth, index=years), pre_rmspe=pre_rmspe,
                     post_rmspe=post_rmspe, ratio=post_rmspe / pre_rmspe,
                     mean_post=float(post.mean()), X1=X1, X0=X0)


def placebo(spec, treated, donors, seed=0):
    main = spec.run(treated, donors, seed)
    res = {treated: main}
    for j in donors:
        others = [d for d in donors if d != j]
        res[j] = spec.run(j, others, seed)
    ratios = pd.Series({k: r['ratio'] for k, r in res.items()})
    means = pd.Series({k: r['mean_post'] for k, r in res.items()})
    n = len(ratios)
    p_ratio = (ratios >= ratios[treated]).sum() / n
    # directional: share of units with standardised mean post gap at least as negative as Iran's
    z = means / pd.Series({k: r['pre_rmspe'] for k, r in res.items()})
    p_neg = (z <= z[treated]).sum() / n
    p_pos = (z >= z[treated]).sum() / n
    return main, res, p_ratio, p_neg, p_pos


def conformal_p(panel, outcome, treated, donors, t0, end, fit_years_all):
    """CWZ (2021) moving-block permutation test of H0: tau_t = 0 for t in [t0, end].
    Outcome-only constrained SC fitted on all periods under H0; statistic = mean |u_t| over post."""
    P = panel[panel.iso.isin([treated] + list(donors))]
    Y = P.pivot(index='year', columns='iso', values=outcome).reindex(columns=[treated] + list(donors))
    yrs = [t for t in fit_years_all if t <= end]
    Y = Y.loc[yrs].dropna(axis=1, how='any')
    if treated not in Y.columns:
        return np.nan
    y1 = Y[treated].values; Y0 = Y.drop(columns=treated).values
    w = solve_w(y1, Y0, np.ones(len(y1)))
    w = polish(y1, Y0, np.ones(len(y1)), w)
    u = y1 - Y0 @ w
    post = np.array([t >= t0 for t in yrs])
    T, Tpost = len(u), post.sum()
    S = lambda e: np.mean(np.abs(e[-Tpost:]))
    # order so that post periods are last (they already are, years sorted)
    s0 = S(u)
    stats = [S(np.roll(u, k)) for k in range(T)]
    return float(np.mean(np.array(stats) >= s0 - 1e-12))
