"""Application: Iran's 2012 sanctions. Produces every number used in Section 6 of the paper."""
import numpy as np, pandas as pd, pickle, warnings, sys
warnings.filterwarnings('ignore')
from ebsc import (phase_leverage, donor_factors, shock_leverage, partial_leverage, exposure_imbalance, exposure_effects,
                  ebsc_path, easc, easc_tuned, min_imbalance, bias_aware_ci, breakdown_M, cv_bias_aware, _sc_weights)
from modern import gap as mgap, ESTIMATORS, _gsc

P = pd.read_csv('../data/panel_2012.csv'); O = pd.read_csv('../data/oilrents.csv'); Br = pd.read_csv('../data/brent.csv')
BASE = ['KAZ', 'NGA', 'ECU', 'MEX', 'COL', 'JOR', 'ROU', 'BGR', 'VNM', 'ZAF', 'PHL', 'THA', 'KEN', 'BRA', 'CHL', 'PER', 'CRI', 'DOM', 'PAN']
EXT = BASE + ['AZE', 'AGO']
YEARS = np.arange(1996, 2025)
PRE = YEARS < 2012; POST = ~PRE
PH = {'shock': (2012, 2015), 'relief': (2016, 2017), 'siege': (2018, 2024)}
X = np.log(Br.set_index('year').brent.loc[YEARS].values)
S_RENTS = O[O.year.between(1996, 2011)].groupby('iso').oilrent.mean()
S_RENTS = S_RENTS.reindex(sorted(set(EXT) | {'IRN'})).fillna(0.0)          # Dominican Rep., Panama: no production
vd = P[P.year.between(1996, 2006)].groupby('iso').oil_share.mean()          # V-Dem oil income measure (robustness)
S_RENTS_9605 = O[O.year.between(1996, 2005)].groupby('iso').oilrent.mean().reindex(S_RENTS.index).fillna(0.0)
S_RENTS_0211 = O[O.year.between(2002, 2011)].groupby('iso').oilrent.mean().reindex(S_RENTS.index).fillna(0.0)

def wide(pool, var='lgdppc'):
    Y = P[P.iso.isin(['IRN'] + pool) & P.year.between(1996, 2024)].pivot(index='year', columns='iso', values=var)
    return Y[['IRN'] + pool]

def phases(g):
    return {k: float(np.mean(g[(YEARS >= a) & (YEARS <= b)])) for k, (a, b) in PH.items()}

def analyse(pool, s_ser, label, k=2, controls=True, treated='IRN', Ydf=None, quiet=False):
    Y = (Ydf if Ydf is not None else wide(pool))
    y1 = Y[treated].values; Y0 = Y[pool].values
    s1 = float(s_ser[treated]); s0 = s_ser[pool].values.astype(float)
    F, _ = donor_factors(Y0, k=k); G = np.column_stack([np.ones(len(YEARS)), F])
    kap = shock_leverage(G, PRE)
    Fl, _ = donor_factors(Y0, k=k, s=s0); pl, r2 = partial_leverage(X, Fl, PRE)
    pl_all, r2_all = partial_leverage(X, F, PRE); kap_l = shock_leverage(np.column_stack([np.ones(len(YEARS)), Fl]), PRE)
    phi, se = exposure_effects(Y0, s0, PRE, list(YEARS).index(2011), controls=controls)
    w_sc = _sc_weights(y1[PRE], Y0[PRE]); r_sc = float(np.sqrt(np.mean((y1[PRE] - Y0[PRE] @ w_sc) ** 2)))
    g_sc = y1 - Y0 @ w_sc
    g_ea, ei_sc = easc(y1, Y0, w_sc, s1, s0, phi)
    best, path = easc_tuned(y1, Y0, PRE, s1, s0, phi, se, kap_l)
    g_eb = y1 - Y0 @ best['w']; g_eat, ei_t = easc(y1, Y0, best['w'], s1, s0, phi)
    pmin = path[0]; g_ebmin = y1 - Y0 @ pmin['w']
    out = dict(label=label, s1=s1, s0=s0, partial_all=pl_all, r2_all=r2_all, F=F, Fl=Fl, dmin=min_imbalance(s1, s0), kappa=kap, kappa_lat=kap_l, partial=pl, r2=r2,
               phi=phi, se_phi=se, w_sc=w_sc, rmspe_sc=r_sc, ei_sc=ei_sc, g_sc=g_sc, g_easc=g_ea,
               best=best, path=path, g_ebsc_tuned=g_eb, g_easc_tuned=g_eat, ei_tuned=ei_t,
               g_ebsc_min=g_ebmin, ei_min=pmin['ei'], rmspe_min=pmin['rmspe'], pool=pool)
    if not quiet:
        print(f"\n=== {label}: s1={s1:.2f}, donors [{s0.min():.2f}, {s0.max():.2f}], dist to hull {out['dmin']:.2f}")
        print('  SC     EI=%6.2f rmspe=%.4f' % (ei_sc, r_sc), {k: round(v, 3) for k, v in phases(g_sc).items()})
        print('  EASC   EI=%6.2f            ' % ei_sc, {k: round(v, 3) for k, v in phases(g_ea).items()})
        print('  EBSC-min EI=%6.2f rmspe=%.4f' % (pmin['ei'], pmin['rmspe']), {k: round(v, 3) for k, v in phases(g_ebmin).items()})
        print('  EBSC*  EI=%6.2f rmspe=%.4f frac=%.3f' % (best['ei'], best['rmspe'], best['frac']), {k: round(v, 3) for k, v in phases(g_eb).items()})
        print('  EASC*  EI=%6.2f            ' % ei_t, {k: round(v, 3) for k, v in phases(g_eat).items()},
              {pool[i]: round(best['w'][i], 3) for i in np.argsort(-best['w'])[:5] if best['w'][i] > 0.005})
    return out

if __name__ == '__main__':
    R = {}
    R['base'] = analyse(BASE, S_RENTS, 'Normalisers (19), oil rents')
    R['ext'] = analyse(EXT, S_RENTS, 'Normalisers + AZE, AGO (21), oil rents')
    # ------------- diagnostics printout
    b = R['base']
    print('\npartial leverage of oil (pre R2=%.3f):' % b['r2'], ' '.join(f"{t}:{v:+.1f}" for t, v in zip(YEARS, b['partial']) if t >= 2008))
    kap_full = shock_leverage(np.column_stack([np.ones(len(YEARS)), b['Fl'], X]), PRE)
    print('kappa_t with g_t = (1, lambda_t, x_t):', ' '.join(f"{t}:{v:.1f}" for t, v in zip(YEARS, kap_full) if t >= 2010), '| pre mean kappa^2 =', round(float(np.mean(kap_full[PRE] ** 2)), 2))
    print('phi x100:', ' '.join(f"{t}:{p*100:+.2f}({s*100:.2f})" for t, p, s in zip(YEARS, b['phi'], b['se_phi']) if t >= 2012))
    # ------------- exposure imbalance of standard estimators (weight-based)
    EI = {}
    for pool_key, pool in [('base', BASE), ('ext', EXT)]:
        Y = wide(pool); s1 = S_RENTS['IRN']; s0 = S_RENTS[pool].values
        rows = {}
        for e in ['sc', 'psc', 'ascm', 'sdid', 'dsc', 'mc', 'gsc', 'rsc']:
            g, info = mgap(Y, 2012, e)
            w = info.get('w')
            ei = exposure_imbalance(s1, s0, np.asarray(w)) if w is not None else np.nan
            ph = phases(g.values)
            ea = {k: np.nan for k in PH}
            if w is not None:
                ge, _ = easc(Y['IRN'].values, Y[pool].values, np.asarray(w), s1, s0, R[pool_key]['phi'])
                ea = phases(g.values + (ge - (Y['IRN'].values - Y[pool].values @ np.asarray(w))))  # estimator's own gap minus phi_t * EI(w)
            rows[e] = dict(ei=ei, **{f'g_{k}': v for k, v in ph.items()}, **{f'ea_{k}': v for k, v in ea.items()})
        EI[pool_key] = pd.DataFrame(rows).T
        print(f'\nExposure imbalance and augmented gaps, {pool_key}:'); print(EI[pool_key].round(3).to_string())
    R['EI'] = EI
    # ------------- robustness of EASC: exposure measure, controls, k, pools
    rob = []
    for nm, pool, sser, kk, ctl in [('Oil rents 1996-2011 (baseline)', BASE, S_RENTS, 2, True),
                                    ('Oil rents 2002-2011', BASE, S_RENTS_0211, 2, True),
                                    ('V-Dem oil income share', BASE, vd.reindex(S_RENTS.index).fillna(0), 2, True),
                                    ('No pre-treatment growth controls in the exposure regression', BASE, S_RENTS, 2, False),
                                    ('Three latent factors', BASE, S_RENTS, 3, True),
                                    ('One latent factor', BASE, S_RENTS, 1, True),
                                    ('Exposure-feasible pool (21)', EXT, S_RENTS, 2, True),
                                    ('Exposure-feasible pool, V-Dem share', EXT, vd.reindex(S_RENTS.index).fillna(0), 2, True),
                                    ('Exposure-feasible pool without Azerbaijan (20)', BASE + ['AGO'], S_RENTS, 2, True),
                                    ('Exposure-feasible pool without Angola (20)', BASE + ['AZE'], S_RENTS, 2, True),
                                    ('Exposure-feasible pool, oil rents 1996--2005', EXT, S_RENTS_9605, 2, True),
                                    ('Exposure-feasible pool, three latent factors', EXT, S_RENTS, 3, True),
                                    ('Exposure-feasible pool, no growth controls', EXT, S_RENTS, 2, False)]:
        r = analyse(pool, sser, nm, k=kk, controls=ctl, quiet=True)
        rob.append(dict(spec=nm, ei_sc=r['ei_sc'], **{f'sc_{k}': v for k, v in phases(r['g_sc']).items()},
                        **{f'easc_{k}': v for k, v in phases(r['g_easc']).items()},
                        **{f'easct_{k}': v for k, v in phases(r['g_easc_tuned']).items()}, ei_t=r['ei_tuned'],
                        **{f'ebmin_{k}': v for k, v in phases(r['g_ebsc_min']).items()}, rmspe_min=r['rmspe_min'], dmin=r['dmin']))
    R['rob'] = pd.DataFrame(rob); print('\nRobustness:'); print(R['rob'].round(3).to_string())
    pickle.dump(R, open('../results/app_main.pkl', 'wb'))
