"""Writes Section 5 of the paper with every number taken from the Monte Carlo summaries."""
import sys, json, numpy as np
tag = sys.argv[1] if len(sys.argv) > 1 else 'mc_final'
sys.argv = [sys.argv[0], tag]
from mc_summary import B, C, D, res as RES
cal = json.load(open('../results/mc_calibration.json'))
APP = json.load(open('../results/app_numbers.json'))['LEV']['ell']
PHI = json.load(open('../results/phi_phase.json'))['ext']
dg = D.xs('mean', axis=1, level=1)


def b(e, s, p='siege', k='bias'):
    return float(B[(B.est == e) & (B.scn == s) & (B.phase == p)][k].iloc[0])


def c(e, s, M, p='siege', k='cover'):
    return float(C[(C.est == e) & (C.scn == s) & (C.phase == p) & (C.M == M)][k].iloc[0])


def f(v, d=3):
    return (f'$-${abs(v):.{d}f}' if v < -0.5 * 10 ** -d else f'{abs(v):.{d}f}')


def rng(vals, d=2):
    return f'{min(vals):.{d}f}--{max(vals):.{d}f}'


T = r"""
\subsection{Design}\label{sec:mc-design}

The simulations reproduce the main features of the application, with one deliberate exception: the baseline designs keep latent leverage moderate so that the exposure channel can be isolated, and design S9 then raises it to the level seen in the application. There are $T=29$ years (1996--2024), and treatment starts in 2012. The observed shock $x_t$ is the actual log Brent price, centred on its 1996--2011 mean. Untreated outcomes follow
\begin{equation}\label{eq:dgp}
Y_{jt}^N=a_j+d_t+\theta_jx_t+\mu_jf_t+\nu_jh_t+\varepsilon_{jt},
\end{equation}
with a latent trend $f_t=(t-2003.5)/10$ and a latent random walk $h_t$ with innovation s.d.\ 0.03, redrawn in each replication. The errors $\varepsilon_{jt}$ are AR(1) with coefficient 0.5 and marginal s.d.\ 0.015; $d_t=0.02(t-1996)$ and $a_j\sim N(0,0.3^2)$ is a unit effect. Exposure is linear, $\theta_j=\gamma s_j$ with $\gamma=GAMMA$, and $s_j$ is the actual 1996--2011 mean oil rent of each donor. The trend loading is $\mu_j=\xi_j-\gamma\varrho s_j$ with $\xi_j\sim N(0,0.08^2)$, where $\varrho=BSLOPE$ is the pre-2012 slope of $x_t$ on $f_t$. Composite loadings $\tilde\mu_j=\xi_j$ are therefore unrelated to exposure, and pre-treatment fit carries no information about it: the situation of Corollary~\ref{cor:fwl}. The loadings on $h_t$ are $\nu_j\sim N(0,1)$. The treated unit has $s_1=22.87$, Iran's value, and $a_1=\xi_1=\nu_1=0$, so it lies at the centre of the donors' latent loadings. The treatment effect is $-0.10$ in 2012--15 and $-0.05$ thereafter.

The calibration matches the application on the dimensions that matter. The pre-2012 $R^2$ of $x_t$ on the latent trend is R2CAL (0.92 in the application). The average partial leverage of $x_t$ is ELLREL in 2016--17 and ELLSIE in 2018--24 (in the application, $\hat\ell_t$ averages APPLREL and APPLSIE). The implied out-of-span exposure effect $\phi_t=\gamma(r_t-r_{2011})$ averages PHIREL and PHISIE per percentage point of oil rents in the two phases, against estimates of PHIAPPREL and PHIAPPSIE in the application.

There are twelve designs:
\begin{description}[itemsep=0pt,font=\normalfont\itshape]
\item[S0] no exposure channel ($\gamma=0$);
\item[S1] in-span shock: after 2012, $x_t$ follows its pre-2012 relation with $f_t$;
\item[S2] baseline: the actual Brent path, with the treated unit outside the hull of the 19 donor exposures (maximum 16.56);
\item[S3] as S2 with 21 donors, adding exposures of 26.52 and 38.42, so that the treated unit is inside the hull;
\item[S4] as S2, with every unit's exposure observed with multiplicative log-normal error (s.d.\ 0.3);
\item[S5] as S2, with concave exposure $\theta_j=\gamma c(1-e^{-s_j/c})$, $c=20$, while the estimators assume linearity;
\item[S6] as S5 with the 21-donor pool;
\item[S7] as S2 with 38 donors (each exposure value twice, with independent loadings);
\item[S8] as S3, but composite trend loadings are correlated with exposure, $\xi_j=N(0,0.08^2)+0.004(s_j-\bar s)$, so that a regression of outcome changes on exposure alone would be confounded;
\item[S9] as S3, but the latent random walk's innovation standard deviation rises from 0.03 to 0.30 after 2014, which produces post-2015 latent leverage of the order seen in the application;
\item[S10] S8 and S9 combined, with the treated unit's trend loading two standard deviations above the donor mean, so that it lies at the edge of the donors' latent distribution as well;
\item[S11] as S3, with a second, unobserved out-of-span shock $z_t$ (zero before 2015, falling to $-1$ by 2024) whose loadings are $0.004s_j$ plus noise for donors, while the treated unit's loading is 0.06 above what its exposure predicts: a treated-specific component that no estimator can recover.
\end{description}
Designs S0--S3 and S7 satisfy the assumptions of the correction, S4--S6 bend the exposure index, and S8--S11 are built to stress the latent structure. Each design has 500 replications. The estimators are synthetic control, ridge-augmented SC, synthetic DiD, de-meaned SC, generalized SC, matrix completion, EBSC-min, EASC and EASC$^*$, tuned as in the application. For synthetic control and EASC, the full inference procedure of Section~\ref{sec:inference}, including all in-space placebos, is run in every replication.

\subsection{Bias and precision}

Table~\ref{tab:mc-bias} reports bias and RMSE of the 2018--24 average; Figure~\ref{fig:mc-rmse} shows RMSE for both later phases and Table~\ref{tab:mc-bias-app} the earlier ones. Four results stand out.

First, without a silent factor (S0, S1), every estimator is approximately unbiased. EASC then pays for estimating a correction it does not need: its RMSE is EASC_S0 in S0 and EASC_S1 in S1, against SC_S0 and SC_S1 for synthetic control. The diagnostics distinguish S1 from the out-of-span designs: the post-treatment maximum of $|\hat\ell_t|$ averages PL_S1 in S1 and PL_S2 in S2 (Table~\ref{tab:mc-diag}). In S0 the shock is out of span but outcomes do not depend on it. The exposure regression then estimates $\phi_t\approx0$, and EASC differs from SC only by noise.

Second, when the shock is out of span and the treated unit lies outside the exposure hull (S2), every standard estimator that weights donors is badly biased. The 2018--24 bias is SC_S2B for synthetic control, SDID_S2B for synthetic DiD, DSC_S2B for de-meaned SC and MC_S2B for matrix completion. These biases are three to four and a half times the true effect of $-0.05$, and all carry the sign that the application's synthetic control implies. Augmented SC (ASCM_S2B) and generalized SC (GSC_S2B) partly offset the bias by extrapolating. EBSC-min fails as Proposition~\ref{prop:geometry} predicts: balancing as far as the simplex allows destroys the fit (RMSE EBMIN_S2). EASC is unbiased (EASC_S2B), with an RMSE of EASC_S2, well under half that of synthetic control (SC_S2).

Third, when the treated unit is inside the hull (S3), the problem is milder, because synthetic control can draw on exposed donors (its average imbalance falls from EI_S2 to EI_S3). Exposure balance now works: EBSC-min has bias EBMIN_S3B and RMSE EBMIN_S3, and EASC and EASC$^*$ have the smallest RMSE of all estimators (EASC_S3). With twice as many donors (S7), EASC's RMSE falls to EASC_S7, against SC_S7 for synthetic control, as the exposure regression becomes more precise.

Fourth, EASC degrades gracefully when its assumptions are strained. Measurement error in exposure (S4) leaves its bias small (EASC_S4B) but raises its RMSE to EASC_S4, still below synthetic control's SC_S4. Under concave exposure with the treated unit outside the hull (S5), the linear correction extrapolates beyond the donors' support and over-corrects (bias EASC_S5B). When the support covers the treated unit (S6), the bias falls to EASC_S6B and the RMSE to EASC_S6R, against SC_S6R for synthetic control. This is Remark~\ref{rem:support} at work: what matters is support for the correction, not for the weights.

Table~\ref{tab:mc-adverse} reports the four adverse designs next to S3, their common baseline. Correlation between composite loadings and exposure (S8) does no harm: the growth controls recover the loadings whatever their correlation with exposure, as Assumption~\ref{ass:span} requires, and EASC's 2018--24 bias is EASC_S8B with RMSE EASC_S8, against SC_S8B and SC_S8 for synthetic control. The design shows why the controls belong in the regression. When latent leverage is high (S9), the mean 2018--24 $\hat\kappa$ for synthetic control is KB_S9, against KB_S3 in S3, and every estimator's RMSE rises. EASC remains close to unbiased (EASC_S9B), but its RMSE (EASC_S9) no longer falls below that of synthetic control (SC_S9): the variance of the correction adds to a noise level that now dominates. The combined design (S10) is the hardest: EASC has bias EASC_S10B and RMSE EASC_S10, synthetic control SC_S10B and SC_S10, EBSC-min EBMIN_S10B and EBMIN_S10. Here the treated unit sits at the edge of the donors' latent distribution while the exposure imbalance remains large, and no estimator does well. EASC's bias carries the sign of the correction it applies, the pattern to expect when the weights cannot match the treated unit's loadings and the correction is scaled by a large imbalance. The hidden-shock design (S11) separates what the correction can and cannot do. The exposure regression absorbs the exposure-related part of the unobserved shock without needing to know what the shock is; the treated-specific part, worth $-0.042$ in the 2018--24 average, remains in every estimator. EASC's bias is EASC_S11B, essentially that irreducible part, against SC_S11B for synthetic control and MC_S11X for matrix completion.

\input{tables/tab_mc_bias}
\input{tables/tab_mc_adverse}

\begin{figure}[htbp]\centering
\includegraphics[width=\textwidth]{figures/fig9_mc_rmse.pdf}
\caption{Monte Carlo: RMSE of the 2016--17 and 2018--24 averages by design. Values above 0.25 are plotted at 0.25.}
\label{fig:mc-rmse}
\end{figure}

\subsection{Inference}

Table~\ref{tab:mc-cover} and Figure~\ref{fig:mc-coverage} report the coverage of the bias-aware intervals. For synthetic control, intervals that ignore bias ($M=0$) under-cover whenever the silent factor is active: coverage of the 2018--24 effect is SCM0_S2 in S2, SCM0_S4 in S4 and SCM0_S5 in S5. Even in S0, where only latent drift matters, it is SCM0_S0. Coverage rises with $M$, to SCM05_RANGE at $M=0.5$ and SCM1_RANGE at $M=1$ across designs, as Proposition~\ref{prop:leverage} implies. The price is length: in S2 the average interval for 2018--24 is SCL05_S2 log points long at $M=0.5$ and SCL1_S2 at $M=1$. EASC intervals at $M=0$ already cover in most designs (EAM0_RANGE across S0--S3, S6 and S7), because the correction removes the silent-factor bias and its estimation error enters the variance. They are also shorter than the synthetic-control intervals that achieve coverage (EAL0_S2 in S2). Under measurement error in exposure (S4), EASC coverage at $M=0$ falls to EAM0_S4 and rises to EAM05_S4 at $M=0.5$ and EAM1_S4 at $M=1$. The robust noise scale gives similar results (Table~\ref{tab:mc-cover-mad}). In the adverse designs (Table~\ref{tab:mc-cover-adverse}), EASC coverage of the 2018--24 effect at $M=0$ is EAM0_S8, EAM0_S9, EAM0_S10 and EAM0_S11 in S8--S11; at $M=0.5$ it is EAM05_S8, EAM05_S9, EAM05_S10 and EAM05_S11. Synthetic control at $M=0$ covers SCM0_S8, SCM0_S9, SCM0_S10 and SCM0_S11. In S8--S10 the intervals do what they are meant to do: when the assumptions behind an estimator fail, the bias-aware interval at a moderate $M$ still covers, at the cost of length. In S11 the treated-specific loading is invisible to the pre-treatment fit, so no multiple of the pre-treatment misfit bounds it, and coverage at $M=0.5$ stays below nominal for both estimators. That is the case the diagnostics cannot detect, and the reason the application treats its later-phase estimates as unidentified rather than corrected.

\input{tables/tab_mc_cover}

\begin{figure}[htbp]\centering
\includegraphics[width=\textwidth]{figures/fig10_mc_coverage.pdf}
\caption{Monte Carlo: coverage of 95\% bias-aware intervals for the 2018--24 average as a function of $M$. Dashed line: nominal level.}
\label{fig:mc-coverage}
\end{figure}

In sum, the simulations support four practical conclusions. Pre-treatment fit and placebo inference give no warning when a silent factor is present; the partial-leverage diagnostic does. Exposure augmentation removes the resulting bias at a moderate cost in variance, provided the exposure regression covers the treated unit. Bias-aware intervals are needed for synthetic control, and advisable for EASC, whenever leverage is high. And when the treated unit is unusual in ways that neither exposure nor pre-treatment growth reveal, EASC trades a large known bias for a smaller unknown one: an improvement, not a solution.
"""
S = sorted(set(B.scn))
rep = {
    'APPLREL': f(np.mean([APP[str(t)] for t in (2016, 2017)]), 1), 'APPLSIE': f(np.mean([APP[str(t)] for t in range(2018, 2025)]), 1),
    'PHIAPPREL': f(PHI['relief'][0], 4), 'PHIAPPSIE': f(PHI['siege'][0], 4),
    'GAMMA': f"{cal['gamma']}", 'BSLOPE': f"{cal['slope']:.2f}", 'R2CAL': f"{cal['r2']:.2f}",
    'ELLREL': f(cal['ell']['relief'], 1), 'ELLSIE': f(cal['ell']['siege'], 1),
    'PHIREL': f(cal['phi_implied']['relief'], 4), 'PHISIE': f(cal['phi_implied']['siege'], 4),
    'EASC_S0': f(b('EASC', 'S0', k='rmse')), 'EASC_S1': f(b('EASC', 'S1', k='rmse')),
    'SC_S0': f(b('SC', 'S0', k='rmse')), 'SC_S1': f(b('SC', 'S1', k='rmse')),
    'PL_S1': f"{dg.loc['S1', 'plmax']:.1f}", 'PL_S2': f"{dg.loc['S2', 'plmax']:.1f}",
    'SC_S2B': f(b('SC', 'S2')), 'SDID_S2B': f(b('SDID', 'S2')), 'DSC_S2B': f(b('DSC', 'S2')), 'MC_S2B': f(b('MC', 'S2')),
    'ASCM_S2B': f(b('ASCM', 'S2')), 'GSC_S2B': f(b('GSC', 'S2')), 'EBMIN_S2': f(b('EBSC-min', 'S2', k='rmse')),
    'EASC_S2B': f(b('EASC', 'S2')), 'EASC_S2': f(b('EASC', 'S2', k='rmse')), 'SC_S2': f(b('SC', 'S2', k='rmse')),
    'EI_S2': f"{dg.loc['S2', 'ei_sc']:.1f}", 'EI_S3': f"{dg.loc['S3', 'ei_sc']:.1f}",
    'EASCST_S3': f(b('EASC*', 'S3', k='rmse')),
    **{f'{e}_{sc}B': f(b(E, sc)) for sc in ('S8', 'S9', 'S10', 'S11') if sc in S for e, E in [('EASC', 'EASC'), ('SC', 'SC'), ('EBMIN', 'EBSC-min')]},
    **{f'{e}_{sc}': f(b(E, sc, k='rmse')) for sc in ('S8', 'S9', 'S10', 'S11') if sc in S for e, E in [('EASC', 'EASC'), ('SC', 'SC'), ('EBMIN', 'EBSC-min'), ('SDID', 'SDID'), ('MC', 'MC')]},
    'MC_S11X': f(b('MC', 'S11')) if 'S11' in S else '--',
    **{f'EAM0_{sc}': f"{c('EASC', sc, 0.0):.2f}" for sc in ('S8', 'S9', 'S10', 'S11') if sc in S},
    **{f'EAM05_{sc}': f"{c('EASC', sc, 0.5):.2f}" for sc in ('S8', 'S9', 'S10', 'S11') if sc in S},
    **{f'SCM0_{sc}': f"{c('SC', sc, 0.0):.2f}" for sc in ('S8', 'S9', 'S10', 'S11') if sc in S},
    **{f'KB_{sc}': f"{np.mean([r['inf'][('SC', 'siege', 'kbar')] for r in RES if r['scn'] == sc]):.1f}" for sc in ('S3', 'S9') if sc in S},
    'EBMIN_S3B': f(b('EBSC-min', 'S3')), 'EBMIN_S3': f(b('EBSC-min', 'S3', k='rmse')), 'EASC_S3': f(b('EASC', 'S3', k='rmse')),
    'EASC_S7': f(b('EASC', 'S7', k='rmse')) if 'S7' in S else '--', 'SC_S7': f(b('SC', 'S7', k='rmse')) if 'S7' in S else '--',
    'EASC_S4B': f(b('EASC', 'S4')), 'EASC_S4': f(b('EASC', 'S4', k='rmse')), 'SC_S4': f(b('SC', 'S4', k='rmse')),
    'EASC_S5B': f(b('EASC', 'S5')), 'EASC_S6B': f(b('EASC', 'S6')) if 'S6' in S else '--',
    'SCM0_S2': f"{c('SC', 'S2', 0.0):.2f}", 'SCM0_S4': f"{c('SC', 'S4', 0.0):.2f}", 'SCM0_S5': f"{c('SC', 'S5', 0.0):.2f}",
    'SCM0_S0': f"{c('SC', 'S0', 0.0):.2f}", 'SCM1_RANGE': rng([c('SC', s, 1.0) for s in S]),
    'SCL1_S2': f"{c('SC', 'S2', 1.0, k='len'):.2f}",
    'EAM0_RANGE': rng([c('EASC', s, 0.0) for s in S if s in ('S0', 'S1', 'S2', 'S3', 'S6', 'S7')]),
    'EAL0_S2': f"in S2, {c('EASC', 'S2', 0.0, k='len'):.2f} at $M=0$ and {c('EASC', 'S2', 0.5, k='len'):.2f} at $M=0.5$, against {c('SC', 'S2', 0.5, k='len'):.2f} for synthetic control at $M=0.5$",
    'SCM05_RANGE': rng([c('SC', s, 0.5) for s in S]), 'SCL05_S2': f"{c('SC', 'S2', 0.5, k='len'):.2f}",
    'EAM05_S4': f"{c('EASC', 'S4', 0.5):.2f}", 'EAM1_S4': f"{c('EASC', 'S4', 1.0):.2f}",
    'EASC_S6R': f(b('EASC', 'S6', k='rmse')) if 'S6' in S else '--', 'SC_S6R': f(b('SC', 'S6', k='rmse')) if 'S6' in S else '--',
    'EAM0_S4': f"{c('EASC', 'S4', 0.0):.2f}",
}
for k in sorted(rep, key=len, reverse=True):
    T = T.replace(k, rep[k])
open('../paper/mc_section.tex', 'w').write(T)
print(T[:400]); print({k: v for k, v in rep.items()})
