"""Classic covariate synthetic control (nested V) with oil rents among the predictors: does matching on
exposure as a covariate balance it?"""
import numpy as np, pandas as pd, pickle, json, warnings
warnings.filterwarnings('ignore')
from scm import fit
from ebsc import easc, exposure_imbalance
from app import wide, BASE, EXT, YEARS, PRE, PH, S_RENTS
R = pickle.load(open('../results/app_main.pkl', 'rb'))
out = {}
for key, pool in [('base', BASE), ('ext', EXT)]:
    Y = wide(pool); y1 = Y['IRN'].values; Y0 = Y[pool].values
    def pm(a, b):
        m = (YEARS >= a) & (YEARS <= b); return y1[m].mean(), Y0[m].mean(0)
    rows1, rows0 = [S_RENTS['IRN']], [S_RENTS[pool].values]
    for a, b in [(1996, 2000), (2001, 2005), (2006, 2011)]:
        r1, r0 = pm(a, b); rows1.append(r1); rows0.append(r0)
    rows1.append(y1[YEARS == 2011][0]); rows0.append(Y0[YEARS == 2011][0])
    X1 = np.array(rows1); X0 = np.vstack(rows0)
    w, v = fit(X1, X0, y1[PRE], Y0[PRE], n_starts=5)
    g = y1 - Y0 @ w; ge, ei = easc(y1, Y0, w, S_RENTS['IRN'], S_RENTS[pool].values, R[key]['phi'])
    ph = lambda x: {k: float(np.mean(x[(YEARS >= a) & (YEARS <= b)])) for k, (a, b) in PH.items()}
    out[key] = dict(ei=ei, v_oil=float(v[0]), rmspe=float(np.sqrt(np.mean(g[PRE] ** 2))), g=ph(g), ge=ph(ge),
                    w={pool[i]: round(float(w[i]), 3) for i in np.argsort(-w) if w[i] > 0.005})
    print(key, out[key])
json.dump(out, open('../results/app_adh.json', 'w'), indent=1)
