"""Summaries of the Monte Carlo: bias, RMSE, coverage, CI length, rejection rates."""
import numpy as np, pandas as pd, pickle, sys
tag = sys.argv[1] if len(sys.argv) > 1 else 'mc'
res = pickle.load(open(f'../results/{tag}.pkl', 'rb'))
import os
if tag == 'mc_final':
    for extra in ('mc_extra', 'mc_extra2'):
        if os.path.exists(f'../results/{extra}.pkl'):
            res = res + pickle.load(open(f'../results/{extra}.pkl', 'rb'))
from mc import SCEN, EST, MS, PH
rows = []
for r in res:
    for e in EST:
        for p in PH:
            rows.append(dict(scn=r['scn'], est=e, phase=p, err=r['err'][e][p]))
E = pd.DataFrame(rows)
B = E.groupby(['scn', 'est', 'phase']).err.agg(bias='mean', rmse=lambda v: np.sqrt(np.mean(v ** 2)), sd='std').reset_index()
rows = []
for r in res:
    for (est, p, M), v in r['inf'].items():
        if M in MS:
            rows.append(dict(scn=r['scn'], est=est, phase=p, M=M, cover=float(v[0]), len=float(v[1])))
        elif M == 'rank':
            rows.append(dict(scn=r['scn'], est=est, phase=p, M='rank', cover=float(v <= 0.1), len=float(v)))
C = pd.DataFrame(rows).groupby(['scn', 'est', 'phase', 'M'], dropna=False).agg(cover=('cover', 'mean'), len=('len', 'mean')).reset_index()
D = pd.DataFrame([dict(scn=r['scn'], **r['diag']) for r in res]).groupby('scn').agg(['mean', 'median'])
if __name__ == '__main__':
    pd.set_option('display.width', 250)
    for p in PH:
        print(f'\n=== {p}: bias / rmse');
        print(B[B.phase == p].pivot(index='est', columns='scn', values='bias').reindex(EST).round(3).to_string())
        print(B[B.phase == p].pivot(index='est', columns='scn', values='rmse').reindex(EST).round(3).to_string())
    for p in PH:
        print(f'\n=== coverage {p}')
        c = C[(C.phase == p) & (C.M != 'rank')].pivot_table(index=['est', 'M'], columns='scn', values='cover')
        print(c.round(3).to_string())
        print(C[(C.phase == p) & (C.M != 'rank')].pivot_table(index=['est', 'M'], columns='scn', values='len').round(3).to_string())
        print('rank test rejection at 10%'); print(C[(C.phase == p) & (C.M == 'rank')].pivot_table(index='est', columns='scn', values='cover').round(3).to_string())
    print(D.round(3).T.to_string())
