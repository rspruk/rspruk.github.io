"""Post-processing of generated LaTeX tables: fit every tabular to the text width."""
import glob, re


def wrap_tables(folder='../paper/tables'):
    for fn in glob.glob(f'{folder}/*.tex'):
        s = open(fn).read()
        if 'adjustbox' in s:
            continue
        s = re.sub(r'(\\begin\{tabular\})', r'\\begin{adjustbox}{max width=\\textwidth}\1', s, count=1)
        s = s.replace('\\end{tabular}', '\\end{tabular}\\end{adjustbox}', 1)
        # tables that set tabcolsep before tabular
        s = s.replace('\\begin{adjustbox}{max width=\\textwidth}\\setlength', '\\setlength')
        open(fn, 'w').write(s)
