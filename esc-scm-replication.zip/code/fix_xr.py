"""Cross-document references between main.tex and appendix.tex (xr package with prefixes):
references in the appendix to labels defined in the paper get the prefix M-, and references in the paper
to labels defined in the appendix get the prefix A-. Idempotent."""
import re, glob, os
P = '../paper'
MAIN = [f'{P}/main.tex', f'{P}/mc_section.tex'] + sorted(glob.glob(f'{P}/tables/tab_*.tex'))
APPX = [f'{P}/appendix.tex'] + sorted(glob.glob(f'{P}/tables/tabA_*.tex'))
lab = lambda files: {m for f in files for m in re.findall(r'\\label\{([^}]+)\}', open(f).read())}
LM, LA = lab(MAIN), lab(APPX)
assert not (LM & LA), f'labels defined in both documents: {LM & LA}'
def fix(files, other, prefix):
    for f in files:
        s = open(f).read()
        s2 = re.sub(r'\\(ref|eqref|pageref)\{([^}]+)\}', lambda m: f'\\{m.group(1)}{{{prefix}{m.group(2)}}}' if m.group(2) in other else m.group(0), s)
        if s2 != s:
            open(f, 'w').write(s2)
fix(MAIN, LA, 'A-'); fix(APPX, LM, 'M-')
for f, ext, pre in [(f'{P}/main.tex', 'appendix', 'A-'), (f'{P}/appendix.tex', 'main', 'M-')]:
    s = open(f).read()
    s = s.replace(f'\\externaldocument{{{ext}}}', f'\\externaldocument[{pre}]{{{ext}}}')
    open(f, 'w').write(s)
print('main labels', len(LM), 'appendix labels', len(LA))
