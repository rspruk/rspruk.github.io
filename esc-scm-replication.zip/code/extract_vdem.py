"""How data/vdem_sub.csv and data/vdem_mech.csv were built from V-Dem v16 (vdemdata R package, data/vdem.RData).
git clone https://github.com/vdeminstitute/vdemdata ; then run this with the path to vdem.RData."""
import sys, pyreadr
d = pyreadr.read_r(sys.argv[1]); d = d[list(d.keys())[0]]
iso = 'IRN BGR EGY IDN JOR MYS MAR ROU SRB ZAF TUN TUR VNM KAZ NGA ECU MEX COL PHL THA KEN AZE AGO BRA CHL PER CRI DOM PAN'.split()
base = ['country_name','country_text_id','year','v2x_rule','v2x_corr','v2xcl_prpty','v2x_jucon','v2x_neopat','v2x_libdem','v2x_execorr',
        'e_wbgi_cce','e_wbgi_pve','e_wbgi_rle','e_wbgi_rqe','e_wbgi_gee','e_wbgi_vae','e_miinflat','e_gdppc','e_total_oil_income_pc',
        'e_total_resources_income_pc','e_civil_war','e_pt_coup']
mech = ['country_text_id','year','v2x_ex_military','v2xnp_regcorr','v2exrescon','v2exembez','v2jucorrdc','v2regsupgroupssize']
s = d[d.country_text_id.isin(iso) & (d.year >= 1990)]
s[base].to_csv('data/vdem_sub.csv', index=False); s[mech].to_csv('data/vdem_mech.csv', index=False)
