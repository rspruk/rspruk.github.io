# Replication package

**Synthetic Control under Out-of-Span Common Shocks: Diagnosis, Exposure Balance and Correction**
Rok Spruk, University of Ljubljana. Submitted to the *Journal of Applied Econometrics*.

This package reproduces every number, table and figure in the paper and the Online Appendix. Tables are written as LaTeX and figures as PDF into `paper/`, which also holds the LaTeX sources (`main.tex`, `appendix.tex`, `refs.bib`); Section 5 (`paper/mc_section.tex`) is written by `make_mc_text.py` with its numbers filled in from the simulation results. Compile with `cd paper && latexmk -pdf appendix.tex main.tex`.

## Requirements

Python 3.10 or later and the packages in `requirements.txt` (tested with Python 3.11.15, numpy 2.4.4, scipy 1.17.1, pandas 3.0.2, cvxpy 1.9.3 with CLARABEL, matplotlib 3.10.9):

    pip install -r requirements.txt

The Monte Carlo uses two processes by default (`multiprocessing.Pool(2)` in `code/mc.py`). Change the pool size to match your machine.

## Run

    sh run_all.sh

On two cores the full run takes about an hour: the application takes about 3 minutes and the Monte Carlo (12 designs × 500 replications) about 55.

To re-run on freshly downloaded data (recommended before publication):

    cd code && python get_data.py      # needs internet; writes data/fresh/
    # copy data/fresh/oilrents.csv and data/fresh/brent.csv over data/, then
    WDI_DIR=../data/fresh sh run_all.sh

## Files

| File | Purpose | Output |
| --- | --- | --- |
| `code/build_panel.py` | Merges the WDI extracts, V-Dem v16 and Penn World Table 10.01 into a country-year panel | `data/panel_2012.csv` |
| `code/ebsc.py` | **The method**: latent factors, leverage $\kappa_t$, partial leverage $\ell_t$, exposure imbalance, exposure–fit frontier, EBSC, EASC, EASC\*, bias-aware intervals, breakdown values | library |
| `code/modern.py`, `code/scm.py` | Standard estimators: SC, penalized SC, augmented SC, synthetic DiD, matrix completion, generalized SC, robust SC, de-meaned SC | library |
| `code/app.py` | Application: diagnostics, estimates, exposure imbalance of every estimator, robustness specifications | `results/app_main.pkl` |
| `code/app_inference.py` | Placebos, noise scale, bias-aware intervals, breakdown values | `results/app_inference.pkl` |
| `code/app_robust.py` | In-time placebos, backdating, leave-one-out | `results/app_robust.pkl` |
| `code/phi_phase.py` | Phase averages of the exposure effect with jackknife errors | `results/phi_phase.json` |
| `code/app_adh.py` | Covariate (nested-V) synthetic control with oil rents among the predictors | `results/app_adh.json` |
| `code/app_influence.py` | Hat values and delete-one-donor estimates of the exposure regression; leverage by number of factors | `results/app_influence.json` |
| `code/make_app_outputs.py` | Figures 1–8 and the application tables | `paper/figures`, `paper/tables` |
| `code/mc.py` | Monte Carlo, twelve designs (seed 20261002 + design offset + replication) | `results/mc_final.pkl`, `mc_extra.pkl`, `mc_extra2.pkl` |
| `code/mc_summary.py` | Bias, RMSE, coverage and length by design | printed |
| `code/make_mc_outputs.py`, `code/make_mc_text.py` | Figures 9–10, Monte Carlo tables, and Section 5 of the paper with its numbers filled in | `paper/` |
| `code/fix_xr.py` | Adds the `A-`/`M-` prefixes that the `xr` package needs for references between the paper and the Online Appendix | `paper/*.tex` |
| `code/texutil.py` | Fits generated tables to the text width | library |
| `code/get_data.py` | Fresh download of WDI series, oil rents and the Brent price | `data/fresh/` |
| `code/extract_vdem.py` | How `data/raw/vdem_*.csv` were cut from V-Dem v16 (`vdemdata` R package) | — |

## Data

| File | Source | Note |
| --- | --- | --- |
| `data/raw/data-input.xlsx` | WDI extract for Iran and 12 earlier-study countries, last updated 19 December 2025 | GDP per capita (PPP, constant 2021 $), inflation, trade |
| `data/raw/wdi/*.csv` | WDI API, retrieved 30 September 2026 | Other donors; transcribed from API responses, so re-pull with `get_data.py` |
| `data/oilrents.csv` | WDI NY.GDP.PETR.RT.ZS (oil rents, % of GDP), 1996–2011, retrieved 2 October 2026 | The Dominican Republic and Panama report no values and are set to zero |
| `data/brent.csv` | FRED POILBREUSDA (Brent, US$ per barrel, annual average), retrieved 2 October 2026 | |
| `data/raw/vdem_sub.csv`, `data/raw/vdem_mech.csv` | V-Dem v16 (March 2026) | Includes the Haber–Menaldo petroleum income series used as an alternative exposure index |
| `data/raw/pwt10.01.rda` | Penn World Table 10.01 | Not used in the JAE paper's estimates; kept because `build_panel.py` builds the common panel |

All data are publicly available. The V-Dem, WDI, FRED and PWT terms of use permit redistribution of these extracts for replication.

## Known limitations

- The WDI and oil-rent extracts were transcribed from API responses in a cloud environment. `get_data.py` re-downloads them and prints the largest differences from the shipped files.
- The minimum attainable placebo p-value is 1/20 (normaliser pool) or 1/22 (exposure-feasible pool).
- Matrix completion in the Monte Carlo uses a fixed penalty (1% of the leading singular value, the value the tuning rule selects in the application) to save computation.
