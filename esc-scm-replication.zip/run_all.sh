#!/bin/sh
# Reproduces every number, table and figure in the paper and the Online Appendix (about 40 minutes on two cores).
set -e
cd code
python3 build_panel.py              # -> data/panel_2012.csv
python3 app.py                      # diagnostics, estimates, estimator comparison, robustness -> results/app_main.pkl
python3 app_inference.py            # placebos, bias-aware intervals, breakdown values        -> results/app_inference.pkl
python3 app_robust.py               # in-time placebos, backdating, leave-one-out             -> results/app_robust.pkl
python3 phi_phase.py                # exposure effects by phase                               -> results/phi_phase.json
python3 app_adh.py                  # covariate SC with oil rents as a predictor              -> results/app_adh.json
python3 app_influence.py            # hat values, delete-one phi, leverage by k               -> results/app_influence.json
python3 make_app_outputs.py         # Figures 1-8, application tables                         -> paper/
python3 mc.py 500 S0,S1,S2,S3,S4,S5,S6,S7 mc_final   # Monte Carlo, main designs             -> results/mc_final.pkl
python3 mc.py 500 S8,S9,S10 mc_extra                 # adverse designs                        -> results/mc_extra.pkl
python3 mc.py 500 S11 mc_extra2                      # hidden-shock design                    -> results/mc_extra2.pkl
python3 make_mc_outputs.py mc_final # Figures 9-10, Monte Carlo tables                        -> paper/
python3 make_mc_text.py mc_final    # Section 5 text with numbers                             -> paper/mc_section.tex
python3 fix_xr.py                   # cross-document reference prefixes (xr)
